package com.example.khedutagro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.net.URLEncoder

object MessageSenderHelper {

    fun confirmAndSendSms(
        context: Context,
        recipients: List<FarmerContact>,
        messageText: String,
        onComplete: () -> Unit = {}
    ) {
        if (recipients.isEmpty()) {
            Toast.makeText(context, "Koi khedut ke group pasand karyu nathi!", Toast.LENGTH_SHORT).show()
            return
        }
        if (messageText.isBlank()) {
            Toast.makeText(context, "Message khali chhe!", Toast.LENGTH_SHORT).show()
            return
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "Pehla Settings mathi SMS permission allow karo", Toast.LENGTH_LONG).show()
            return
        }

        val previewNames = recipients.take(5).joinToString(", ") { it.name } +
            if (recipients.size > 5) " (+${recipients.size - 5} bija)" else ""

        AlertDialog.Builder(context)
            .setTitle("Text SMS Moklvo Chhe? (${recipients.size} Khedut)")
            .setMessage("Aa message fakt pasand karela kheduto ne j jase:\n$previewNames\n\nMessage:\n$messageText")
            .setPositiveButton("SMS Moklo (${recipients.size})") { _, _ ->
                var sentCount = 0
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                for (farmer in recipients) {
                    val cleanPhone = AgroRepository.normalizePhone(farmer.phone)
                    if (cleanPhone.length == 10) {
                        try {
                            val parts = smsManager.divideMessage(messageText)
                            smsManager.sendMultipartTextMessage("+91$cleanPhone", null, parts, null, null)
                            sentCount++
                        } catch (_: Exception) {
                        }
                    }
                }
                Toast.makeText(context, "$sentCount kheduto ne Gujarati Text SMS moklai gayo!", Toast.LENGTH_LONG).show()
                onComplete()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun startWhatsAppGuidedQueue(
        context: Context,
        recipients: List<FarmerContact>,
        messageText: String,
        index: Int = 0,
        onAllFinished: () -> Unit = {}
    ) {
        if (recipients.isEmpty()) {
            Toast.makeText(context, "Koi khedut ke group pasand karyu nathi!", Toast.LENGTH_SHORT).show()
            return
        }
        if (messageText.isBlank()) {
            Toast.makeText(context, "Message khali chhe!", Toast.LENGTH_SHORT).show()
            return
        }

        if (recipients.size == 1 && index == 0) {
            openWhatsAppSingle(context, recipients[0], messageText)
            onAllFinished()
            return
        }

        if (index >= recipients.size) {
            Toast.makeText(context, "Badha ${recipients.size} kheduto ne WhatsApp message moklai gaya!", Toast.LENGTH_LONG).show()
            onAllFinished()
            return
        }

        val currentFarmer = recipients[index]
        AlertDialog.Builder(context)
            .setTitle("WhatsApp Sender (${index + 1} / ${recipients.size})")
            .setMessage(
                "Khedut: ${currentFarmer.name} (+91 ${currentFarmer.phone})\n\n" +
                    "1. Niche 'Open WhatsApp' par tap karo\n" +
                    "2. WhatsApp ma Send dabavi ne Back aavo\n" +
                    "3. Pachhi agla khedut mate 'Next' dabavo."
            )
            .setPositiveButton("Open WhatsApp (${index + 1}/${recipients.size})") { _, _ ->
                openWhatsAppSingle(context, currentFarmer, messageText)
                if (index + 1 < recipients.size) {
                    startWhatsAppGuidedQueue(context, recipients, messageText, index + 1, onAllFinished)
                } else {
                    onAllFinished()
                }
            }
            .setNeutralButton("Skip") { _, _ ->
                startWhatsAppGuidedQueue(context, recipients, messageText, index + 1, onAllFinished)
            }
            .setNegativeButton("Stop", null)
            .show()
    }

    private fun openWhatsAppSingle(context: Context, farmer: FarmerContact, messageText: String) {
        val cleanPhone = AgroRepository.normalizePhone(farmer.phone)
        if (cleanPhone.length != 10) {
            Toast.makeText(context, "${farmer.name} no mobile number khoto chhe", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val encoded = URLEncoder.encode(messageText, "UTF-8")
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=91$cleanPhone&text=$encoded")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "WhatsApp khuli shakyu nathi", Toast.LENGTH_SHORT).show()
        }
    }
}
