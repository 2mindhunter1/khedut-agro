package com.example.khedutagro

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.time.LocalDate

class CropMasterAdapter(
    private var crops: List<CropMasterSheet>,
    private val onOpenSheet: (CropMasterSheet) -> Unit,
    private val onLinkSheet: (CropMasterSheet) -> Unit,
    private val onDeleteCrop: (CropMasterSheet) -> Unit
) : RecyclerView.Adapter<CropMasterAdapter.CropVH>() {

    class CropVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvCropName: TextView = v.findViewById(R.id.tvCropName)
        val tvCropSeason: TextView = v.findViewById(R.id.tvCropSeason)
        val tvCropWeatherNote: TextView = v.findViewById(R.id.tvCropWeatherNote)
        val tvCropStageCount: TextView = v.findViewById(R.id.tvCropStageCount)
        val btnOpenSheet: MaterialButton = v.findViewById(R.id.btnOpenSheet)
        val btnLinkSheet: MaterialButton = v.findViewById(R.id.btnLinkSheet)
        val btnDeleteCrop: MaterialButton = v.findViewById(R.id.btnDeleteCrop)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CropVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_crop_card, parent, false)
        return CropVH(v)
    }

    override fun onBindViewHolder(holder: CropVH, position: Int) {
        val c = crops[position]
        holder.tvCropName.text = c.cropName
        holder.tvCropSeason.text = c.season
        holder.tvCropWeatherNote.text = c.weatherNote.ifEmpty { "Pak sheet tamari rite edit kari shakay chhe." }
        holder.tvCropStageCount.text = "Sheet Stages: ${c.stages.size} તબક્કા (Divas 0 thi ${c.stages.maxOfOrNull { it.dayOffset } ?: 0})"

        holder.btnOpenSheet.setOnClickListener { onOpenSheet(c) }
        holder.btnLinkSheet.setOnClickListener { onLinkSheet(c) }
        holder.btnDeleteCrop.setOnClickListener { onDeleteCrop(c) }
        holder.itemView.setOnClickListener { onOpenSheet(c) }
    }

    override fun getItemCount(): Int = crops.size

    fun updateList(newList: List<CropMasterSheet>) {
        crops = newList
        notifyDataSetChanged()
    }
}

class StageRowAdapter(
    private var stages: List<CropStageRow>,
    private val onEditStage: (CropStageRow) -> Unit,
    private val onDeleteStage: (CropStageRow) -> Unit
) : RecyclerView.Adapter<StageRowAdapter.StageVH>() {

    class StageVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvStageDayBadge: TextView = v.findViewById(R.id.tvStageDayBadge)
        val tvStageTitle: TextView = v.findViewById(R.id.tvStageTitle)
        val tvStageMsg: TextView = v.findViewById(R.id.tvStageMsg)
        val btnEditStage: MaterialButton = v.findViewById(R.id.btnEditStage)
        val btnDeleteStage: MaterialButton = v.findViewById(R.id.btnDeleteStage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StageVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_stage_row, parent, false)
        return StageVH(v)
    }

    override fun onBindViewHolder(holder: StageVH, position: Int) {
        val s = stages[position]
        holder.tvStageDayBadge.text = "દિવસ ${s.dayOffset}"
        holder.tvStageTitle.text = s.stageTitle
        holder.tvStageMsg.text = s.messageGujarati
        holder.btnEditStage.setOnClickListener { onEditStage(s) }
        holder.btnDeleteStage.setOnClickListener { onDeleteStage(s) }
    }

    override fun getItemCount(): Int = stages.size

    fun updateStages(newList: List<CropStageRow>) {
        stages = newList
        notifyDataSetChanged()
    }
}

class ScheduleAdapter(
    private var items: List<ScheduledAdvisory>,
    private val onSendSms: (ScheduledAdvisory) -> Unit,
    private val onSendWhatsApp: (ScheduledAdvisory) -> Unit,
    private val onDeleteSchedule: (ScheduledAdvisory) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.SchedVH>() {

    class SchedVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvSchedCropBadge: TextView = v.findViewById(R.id.tvSchedCropBadge)
        val tvSchedStatus: TextView = v.findViewById(R.id.tvSchedStatus)
        val tvSchedDateInfo: TextView = v.findViewById(R.id.tvSchedDateInfo)
        val tvSchedRecipients: TextView = v.findViewById(R.id.tvSchedRecipients)
        val tvSchedMessage: TextView = v.findViewById(R.id.tvSchedMessage)
        val btnSchedSms: MaterialButton = v.findViewById(R.id.btnSchedSms)
        val btnSchedWa: MaterialButton = v.findViewById(R.id.btnSchedWa)
        val btnSchedDel: MaterialButton = v.findViewById(R.id.btnSchedDel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SchedVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_schedule_card, parent, false)
        return SchedVH(v)
    }

    override fun onBindViewHolder(holder: SchedVH, position: Int) {
        val s = items[position]
        val todayIso = LocalDate.now().toString()
        val isDue = !s.isSent && s.targetDateIso <= todayIso

        holder.tvSchedCropBadge.text = "${s.cropName} • દિવસ ${s.dayOffset}"
        when {
            s.isSent -> {
                holder.tvSchedStatus.text = "SENT (${s.sentChannel})"
                holder.tvSchedStatus.setTextColor(Color.parseColor("#2E7D32"))
            }
            isDue -> {
                holder.tvSchedStatus.text = "AAJE DUE CHHE"
                holder.tvSchedStatus.setTextColor(Color.parseColor("#C62828"))
            }
            else -> {
                holder.tvSchedStatus.text = "SCHEDULED"
                holder.tvSchedStatus.setTextColor(Color.parseColor("#1565C0"))
            }
        }

        val repeatStr = if (s.repeatYearly) " • દર વર્ષે રિપીટ" else ""
        holder.tvSchedDateInfo.text =
            "મોકલવાની તારીખ: ${AgroRepository.formatDateDisplay(s.targetDateIso)} (વાવેતર: ${AgroRepository.formatDateDisplay(s.sowingDateIso)})$repeatStr"
        holder.tvSchedRecipients.text = "કોને જશે: ${s.recipientSummary}"
        holder.tvSchedMessage.text = s.messageGujarati

        holder.btnSchedSms.setOnClickListener { onSendSms(s) }
        holder.btnSchedWa.setOnClickListener { onSendWhatsApp(s) }
        holder.btnSchedDel.setOnClickListener { onDeleteSchedule(s) }
    }

    override fun getItemCount(): Int = items.size

    fun updateList(newList: List<ScheduledAdvisory>) {
        items = newList
        notifyDataSetChanged()
    }
}

class FarmerAdapter(
    private var farmers: List<FarmerContact>,
    private var groups: List<FarmerGroup>,
    private val onEditFarmer: (FarmerContact) -> Unit,
    private val onDeleteFarmer: (FarmerContact) -> Unit
) : RecyclerView.Adapter<FarmerAdapter.FarmerVH>() {

    class FarmerVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvFarmerName: TextView = v.findViewById(R.id.tvFarmerName)
        val tvFarmerPhone: TextView = v.findViewById(R.id.tvFarmerPhone)
        val tvFarmerGroups: TextView = v.findViewById(R.id.tvFarmerGroups)
        val btnEditFarmer: MaterialButton = v.findViewById(R.id.btnEditFarmer)
        val btnDeleteFarmer: MaterialButton = v.findViewById(R.id.btnDeleteFarmer)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FarmerVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_farmer_row, parent, false)
        return FarmerVH(v)
    }

    override fun onBindViewHolder(holder: FarmerVH, position: Int) {
        val f = farmers[position]
        holder.tvFarmerName.text = if (f.village.isNotEmpty()) "${f.name} (${f.village})" else f.name
        holder.tvFarmerPhone.text = "+91 ${f.phone}"
        val gNames = groups.filter { it.id in f.groupIds }.map { it.name }
        holder.tvFarmerGroups.text = if (gNames.isEmpty()) "Group: Koi nathi" else "Group: ${gNames.joinToString(", ")}"

        holder.btnEditFarmer.setOnClickListener { onEditFarmer(f) }
        holder.btnDeleteFarmer.setOnClickListener { onDeleteFarmer(f) }
    }

    override fun getItemCount(): Int = farmers.size

    fun updateData(newFarmers: List<FarmerContact>, newGroups: List<FarmerGroup>) {
        farmers = newFarmers
        groups = newGroups
        notifyDataSetChanged()
    }
}

class ApmcRateAdapter(
    private var rates: List<ApmcCropRate>,
    private val onEditRate: (ApmcCropRate) -> Unit,
    private val onDeleteRate: (ApmcCropRate) -> Unit
) : RecyclerView.Adapter<ApmcRateAdapter.RateVH>() {

    class RateVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvRateCropName: TextView = v.findViewById(R.id.tvRateCropName)
        val tvRateValues: TextView = v.findViewById(R.id.tvRateValues)
        val btnEditRate: MaterialButton = v.findViewById(R.id.btnEditRate)
        val btnDeleteRate: MaterialButton = v.findViewById(R.id.btnDeleteRate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RateVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_apmc_rate, parent, false)
        return RateVH(v)
    }

    override fun onBindViewHolder(holder: RateVH, position: Int) {
        val r = rates[position]
        holder.tvRateCropName.text = r.cropName
        holder.tvRateValues.text = "₹${r.minPrice} થી ₹${r.maxPrice} (પ્રતિ ૨૦ કિલો)"
        holder.btnEditRate.setOnClickListener { onEditRate(r) }
        holder.btnDeleteRate.setOnClickListener { onDeleteRate(r) }
    }

    override fun getItemCount(): Int = rates.size

    fun updateRates(newRates: List<ApmcCropRate>) {
        rates = newRates
        notifyDataSetChanged()
    }
}

class PhoneContactPickAdapter(
    private var items: List<Pair<String, String>>,
    private val selectedPhones: MutableSet<String>
) : RecyclerView.Adapter<PhoneContactPickAdapter.PickVH>() {

    class PickVH(v: View) : RecyclerView.ViewHolder(v) {
        val cbPick: CheckBox = v.findViewById(R.id.cbPickContact)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PickVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_pick_contact, parent, false)
        return PickVH(v)
    }

    override fun onBindViewHolder(holder: PickVH, position: Int) {
        val (name, phone) = items[position]
        holder.cbPick.setOnCheckedChangeListener(null)
        holder.cbPick.text = "$name ($phone)"
        holder.cbPick.isChecked = phone in selectedPhones
        holder.cbPick.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) selectedPhones.add(phone) else selectedPhones.remove(phone)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<Pair<String, String>>) {
        items = newItems
        notifyDataSetChanged()
    }
}
