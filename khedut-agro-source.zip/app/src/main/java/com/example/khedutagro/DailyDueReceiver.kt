package com.example.khedutagro

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class DailyDueReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "khedut_agro_daily_due_v1"

        fun scheduleDailyMorningCheck(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val zone = ZoneId.systemDefault()
            val now = LocalDateTime.now(zone)
            var next8Am = now.withHour(8).withMinute(0).withSecond(0).withNano(0)
            if (!next8Am.isAfter(now)) {
                next8Am = next8Am.plusDays(1)
            }
            val triggerMillis = next8Am.atZone(zone).toInstant().toEpochMilli()
            val intent = Intent(context, DailyDueReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                8080,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                triggerMillis,
                AlarmManager.INTERVAL_DAY,
                pi
            )
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val todayIso = LocalDate.now().toString()
        val dueCount = AgroRepository.getSchedules(context).count { !it.isSent && it.targetDateIso <= todayIso }
        if (dueCount <= 0) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Khedut Pak Advisory Alert", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val openPi = PendingIntent.getActivity(
            context,
            8081,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Aaje $dueCount Pak Advisory Message Moklvana Baki Chhe")
            .setContentText("App kholi ne kheduto ne Gujarati ma SMS ke WhatsApp moklo.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .build()

        nm.notify(8082, notif)
    }
}
