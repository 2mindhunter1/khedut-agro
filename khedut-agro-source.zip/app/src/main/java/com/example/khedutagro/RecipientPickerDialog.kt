package com.example.khedutagro

import android.content.Context
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object RecipientPickerDialog {

    fun show(
        context: Context,
        title: String,
        onSelected: (recipients: List<FarmerContact>, summaryLabel: String) -> Unit
    ) {
        val groups = AgroRepository.getGroups(context)
        val farmers = AgroRepository.getFarmers(context)

        if (groups.isEmpty() && farmers.isEmpty()) {
            Toast.makeText(context, "Pehla 'Khedut & Group' tab ma contact add karo!", Toast.LENGTH_LONG).show()
            return
        }

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_pick_recipients, null)
        val containerGroups: LinearLayout = view.findViewById(R.id.containerPickGroups)
        val containerFarmers: LinearLayout = view.findViewById(R.id.containerPickFarmers)

        val chosenGroupIds = mutableSetOf<String>()
        val chosenFarmerIds = mutableSetOf<String>()

        if (groups.isEmpty()) {
            containerGroups.addView(TextView(context).apply { text = "Koi group nathi" })
        } else {
            for (g in groups) {
                val memberCount = farmers.count { g.id in it.groupIds }
                val cb = CheckBox(context).apply {
                    text = "${g.name} ($memberCount ખેડૂત)"
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) chosenGroupIds.add(g.id) else chosenGroupIds.remove(g.id)
                    }
                }
                containerGroups.addView(cb)
            }
        }

        if (farmers.isEmpty()) {
            containerFarmers.addView(TextView(context).apply { text = "Koi individual khedut nathi" })
        } else {
            for (f in farmers) {
                val cb = CheckBox(context).apply {
                    text = "${f.name} (${f.phone})"
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) chosenFarmerIds.add(f.id) else chosenFarmerIds.remove(f.id)
                    }
                }
                containerFarmers.addView(cb)
            }
        }

        AlertDialog.Builder(context)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Confirm Selection") { _, _ ->
                val resolved = AgroRepository.resolveUniqueRecipients(context, chosenGroupIds, chosenFarmerIds)
                if (resolved.isEmpty()) {
                    Toast.makeText(context, "Kam se kam 1 group ke khedut pasand karo!", Toast.LENGTH_SHORT).show()
                } else {
                    val gNames = groups.filter { it.id in chosenGroupIds }.map { it.name }
                    val fNames = farmers.filter { it.id in chosenFarmerIds }.map { it.name }
                    val parts = mutableListOf<String>()
                    if (gNames.isNotEmpty()) parts.add("Group: ${gNames.joinToString(", ")}")
                    if (fNames.isNotEmpty()) parts.add("Khedut: ${fNames.joinToString(", ")}")
                    val summary = "${parts.joinToString(" | ")} (કુલ ${resolved.size} ખેડૂત)"
                    onSelected(resolved, summary)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
