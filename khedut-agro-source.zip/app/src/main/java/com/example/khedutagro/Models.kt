package com.example.khedutagro

data class FarmerGroup(
    val id: String,
    val name: String,
    val description: String = ""
)

data class FarmerContact(
    val id: String,
    val name: String,
    val phone: String, // 10-digit normalized mobile number
    val village: String = "",
    val groupIds: List<String> = emptyList()
)

data class CropStageRow(
    val id: String,
    val dayOffset: Int, // Days after sowing date (e.g., 0, 15, 25, 45)
    val stageTitle: String, // Gujarati stage title
    val messageGujarati: String // Pure Gujarati advisory message
)

data class CropMasterSheet(
    val id: String,
    val cropName: String, // e.g., "જીરું", "કપાસ", "મગફળી"
    val season: String, // e.g., "શિયાળુ (Rabi)", "ચોમાસુ (Kharif)", "ઉનાળુ (Summer)"
    val weatherNote: String,
    val stages: List<CropStageRow>
)

data class ScheduledAdvisory(
    val id: String,
    val batchId: String,
    val cropId: String,
    val cropName: String,
    val sowingDateIso: String, // yyyy-MM-dd
    val targetDateIso: String, // yyyy-MM-dd
    val dayOffset: Int,
    val stageTitle: String,
    val messageGujarati: String,
    val recipientIds: List<String>, // Selected FarmerContact IDs ONLY
    val recipientSummary: String,
    val repeatYearly: Boolean = true,
    val isSent: Boolean = false,
    val sentChannel: String = ""
)

data class ApmcCropRate(
    val id: String,
    val cropName: String,
    val minPrice: Int, // per 20 kg (મણ)
    val maxPrice: Int  // per 20 kg (મણ)
)

data class ApmcYard(
    val id: String,
    val yardName: String, // e.g., "મોરબી APMC", "રાજકોટ APMC"
    val updatedDate: String,
    val rates: List<ApmcCropRate>
)
