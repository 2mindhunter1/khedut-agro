package com.example.khedutagro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

object AgroRepository {

    private const val PREFS_NAME = "khedut_agro_prefs_v1"
    private const val KEY_GROUPS = "groups_json"
    private const val KEY_FARMERS = "farmers_json"
    private const val KEY_CROPS = "crops_json"
    private const val KEY_SCHEDULES = "schedules_json"
    private const val KEY_APMC = "apmc_json"
    private const val KEY_SEEDED = "seeded_v1"

    fun normalizePhone(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return if (digits.length >= 10) digits.takeLast(10) else digits
    }

    fun formatDateDisplay(isoDate: String): String {
        return try {
            val d = LocalDate.parse(isoDate)
            d.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
        } catch (_: Exception) {
            isoDate
        }
    }

    fun ensureSeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SEEDED, false)) return

        val grpJeeru = FarmerGroup(UUID.randomUUID().toString(), "જીરું ગ્રુપ - મોરબી", "શિયાળુ જીરું વાવેતર કરતા ખેડૂતો")
        val grpKapas = FarmerGroup(UUID.randomUUID().toString(), "કપાસ ગ્રુપ - રાજકોટ", "ચોમાસુ કપાસ વાવેતર કરતા ખેડૂતો")
        val grpMagfali = FarmerGroup(UUID.randomUUID().toString(), "મગફળી ગ્રુપ", "મગફળી પાક ગ્રુપ")
        saveGroups(context, listOf(grpJeeru, grpKapas, grpMagfali))

        val sampleFarmers = listOf(
            FarmerContact(UUID.randomUUID().toString(), "રમેશભાઈ પટેલ", "9876543210", "કલ્યાણપર", listOf(grpJeeru.id)),
            FarmerContact(UUID.randomUUID().toString(), "મહેશભાઈ ગજેરા", "9876543211", "ટંકારા", listOf(grpJeeru.id, grpKapas.id))
        )
        saveFarmers(context, sampleFarmers)

        val defaultCrops = listOf(
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "જીરું",
                season = "શિયાળુ (ઠંડી ઋતુ)",
                weatherNote = "સૂકું અને ઠંડું હવામાન ઉત્તમ; વાદળછાયા વાતાવરણમાં ચારાનો રોગ આવે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને પ્રથમ પિયત",
                        "નમસ્તે ખેડૂત મિત્ર, જીરુંના વાવેતર બાદ તરત જ હળવું પિયત આપવું જેથી બીજનો ઉગાવો એકસરખો અને ઝડપી થાય."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        15,
                        "નીંદામણ અને બીજું પિયત",
                        "જીરુંના વાવેતરને ૧૫ દિવસ થયા છે. ખેતરમાંથી નીંદામણ દૂર કરી જરૂરિયાત મુજબ બીજું હળવું પિયત આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        25,
                        "મોલો-મશી અને ચારા નિયંત્રણ",
                        "જીરુંનો પાક ૨૫ દિવસનો થયો છે. વાદળછાયા વાતાવરણ કે ઝાકળમાં ચારો અને મોલો-મશી ન આવે તે માટે ભલામણ મુજબ ફૂગનાશક અને ચૂસિયા પ્રકારની દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "ફૂલ અને દાણા બંધાવવાની અવસ્થા",
                        "જીરુંમાં ફૂલ આવવાની અવસ્થા શરૂ થઈ છે. ઠંડી અને ઝાકળથી પાકને બચાવવા હળવું પિયત આપવું અને પોષક તત્વોનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        70,
                        "દાણા પાકવાની અવસ્થા",
                        "જીરુંના દાણા ભરાવાની અવસ્થા છે. વધારે પડતું પિયત ટાળવું અને પાક પીળો પડવા લાગે ત્યારે કાપણીની તૈયારી કરવી."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "કપાસ",
                season = "ચોમાસુ (ખરીફ ઋતુ)",
                weatherNote = "વધુ વરસાદમાં પાણી ભરાવા ન દેવું; ભેજવાળા વાતાવરણમાં ચૂસિયા જીવાત વધે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને પાયાનું ખાતર",
                        "કપાસના વાવેતર સમયે ભલામણ મુજબ પાયાનું ખાતર આપવું અને ખેતરમાં વરસાદી પાણી ભરાઈ ન રહે તે માટે નિકાલની વ્યવસ્થા રાખવી."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        20,
                        "આંતરખેડ અને ચૂસિયા જીવાત",
                        "કપાસના પાકને ૨૦ દિવસ થયા છે. આંતરખેડ કરી નીંદામણ સાફ કરવું અને તડતડિયા તથા સફેદ માખીના નિયંત્રણ માટે દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "પૂર્તિ ખાતર અને ફૂલ-ભમરી અવસ્થા",
                        "કપાસમાં ફૂલ-ભમરી બેસવાની અવસ્થા છે. નાઈટ્રોજનયુક્ત પૂર્તિ ખાતર આપવું અને ગુલાબી ઈયળ માટે ફેરોમેન ટ્રેપ લગાવવા."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        75,
                        "જીંડવા વિકાસ અને પોષણ",
                        "કપાસમાં જીંડવા વિકાસની અવસ્થા ચાલી રહી છે. પાન લાલ થતા અટકાવવા મેગ્નેશિયમ અને સૂક્ષ્મ તત્વોનો છંટકાવ કરવો."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "મગફળી",
                season = "ચોમાસુ / ઉનાળુ",
                weatherNote = "સૂયા બેસતી વખતે જમીનમાં પૂરતો ભેજ જરૂરી છે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "બીજ માવજત અને વાવેતર",
                        "મગફળીના વાવેતર પહેલા બીજને ફૂગનાશક દવાનો પટ આપવો જેથી ઉગાવો સારો થાય અને મૂળનો સડો અટકે."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        25,
                        "નીંદામણ અને પાનના ટપકા રોગ",
                        "મગફળી ૨૫ દિવસની થઈ છે. નીંદામણ દૂર કરવું અને પાનના ટપકા (ટીક્કા રોગ) ના નિયંત્રણ માટે યોગ્ય દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "સૂયા બેસવાની અવસ્થા અને જીપ્સમ",
                        "મગફળીમાં સૂયા બેસવાની અવસ્થા શરૂ થઈ છે. ડોડવા સારા ભરાય તે માટે જીપ્સમ (ચિરોડી) આપવું અને ભેજ જાળવી રાખવો."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "ઘઉં",
                season = "શિયાળુ (ઠંડી ઋતુ)",
                weatherNote = "શિયાળાની ઠંડી ઘઉંના ફૂટ અને દાણા ભરાવા માટે અનુકૂળ છે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને કોરવાણ પિયત",
                        "ઘઉંના વાવેતર બાદ યોગ્ય સમયે પિયત આપવું અને પાયાના ખાતરનો પૂરો ડોઝ આપવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        21,
                        "તાજમૂળ અવસ્થા (મહત્વનું પિયત)",
                        "ઘઉંના વાવેતરને ૨૧ દિવસ થયા છે. આ તાજમૂળ ફૂટવાની અવસ્થા હોવાથી સમયસર પિયત અને પૂર્તિ ખાતર અવશ્ય આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        55,
                        "કંટી નીકળવાની અવસ્થા",
                        "ઘઉંમાં કંટી નીકળવાની અવસ્થા શરૂ થઈ છે. આ સમયે જમીનમાં ભેજની ખેંચ ન પડે તેનું ખાસ ધ્યાન રાખવું."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "તલ",
                season = "ઉનાળુ (ગરમ ઋતુ)",
                weatherNote = "ઉનાળાની ગરમીમાં નિયમિત અંતરે હળવું પિયત આપવું.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને ઉગાવો",
                        "ઉનાળુ તલના વાવેતર બાદ બીજ ઊગી નીકળે ત્યાં સુધી હળવું પિયત આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        20,
                        "પારવણી અને નીંદામણ",
                        "તલના પાકને ૨૦ દિવસ થયા છે. વધારાના છોડ દૂર કરી પારવણી કરવી અને નીંદામણ સાફ કરવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        40,
                        "ફૂલ અને બૈઢા બેસવાની અવસ્થા",
                        "તલમાં ફૂલ અને બૈઢા બેસવાની અવસ્થા છે. પાન વાળનારી ઈયળ અને ચૂસિયા જીવાત માટે દવાનો છંટકાવ કરવો."
                    )
                )
            )
        )
        saveCrops(context, defaultCrops)

        val todayDisplay = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
        val defaultApmc = listOf(
            ApmcYard(
                id = UUID.randomUUID().toString(),
                yardName = "મોરબી APMC",
                updatedDate = todayDisplay,
                rates = listOf(
                    ApmcCropRate(UUID.randomUUID().toString(), "જીરું", 4200, 4650),
                    ApmcCropRate(UUID.randomUUID().toString(), "કપાસ", 1420, 1560),
                    ApmcCropRate(UUID.randomUUID().toString(), "મગફળી જાડી", 1050, 1210),
                    ApmcCropRate(UUID.randomUUID().toString(), "ઘઉં ટુકડા", 510, 585),
                    ApmcCropRate(UUID.randomUUID().toString(), "તલ સફેદ", 2100, 2450)
                )
            ),
            ApmcYard(
                id = UUID.randomUUID().toString(),
                yardName = "રાજકોટ APMC",
                updatedDate = todayDisplay,
                rates = listOf(
                    ApmcCropRate(UUID.randomUUID().toString(), "જીરું", 4250, 4720),
                    ApmcCropRate(UUID.randomUUID().toString(), "કપાસ", 1450, 1590),
                    ApmcCropRate(UUID.randomUUID().toString(), "મગફળી ઝીણી", 1080, 1240),
                    ApmcCropRate(UUID.randomUUID().toString(), "ચણા", 1120, 1260),
                    ApmcCropRate(UUID.randomUUID().toString(), "ધાણા", 1300, 1520)
                )
            )
        )
        saveApmcYards(context, defaultApmc)

        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    // --- GROUPS ---
    fun getGroups(context: Context): List<FarmerGroup> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GROUPS, "[]") ?: "[]"
        val list = mutableListOf<FarmerGroup>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(FarmerGroup(o.getString("id"), o.getString("name"), o.optString("description", "")))
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveGroups(context: Context, groups: List<FarmerGroup>) {
        val arr = JSONArray()
        for (g in groups) {
            arr.put(JSONObject().apply {
                put("id", g.id)
                put("name", g.name)
                put("description", g.description)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GROUPS, arr.toString()).apply()
    }

    fun addGroup(context: Context, name: String, desc: String) {
        val all = getGroups(context).toMutableList()
        all.add(FarmerGroup(UUID.randomUUID().toString(), name, desc))
        saveGroups(context, all)
    }

    fun deleteGroup(context: Context, groupId: String) {
        val all = getGroups(context).filterNot { it.id == groupId }
        saveGroups(context, all)
        // Remove groupId from farmers
        val updatedFarmers = getFarmers(context).map { f ->
            f.copy(groupIds = f.groupIds.filterNot { it == groupId })
        }
        saveFarmers(context, updatedFarmers)
    }

    // --- FARMERS ---
    fun getFarmers(context: Context): List<FarmerContact> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_FARMERS, "[]") ?: "[]"
        val list = mutableListOf<FarmerContact>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val gIds = mutableListOf<String>()
                val gArr = o.optJSONArray("groupIds")
                if (gArr != null) {
                    for (j in 0 until gArr.length()) gIds.add(gArr.getString(j))
                }
                list.add(
                    FarmerContact(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        phone = o.getString("phone"),
                        village = o.optString("village", ""),
                        groupIds = gIds
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedBy { it.name }
    }

    fun saveFarmers(context: Context, farmers: List<FarmerContact>) {
        val arr = JSONArray()
        for (f in farmers) {
            val gArr = JSONArray()
            f.groupIds.forEach { gArr.put(it) }
            arr.put(JSONObject().apply {
                put("id", f.id)
                put("name", f.name)
                put("phone", f.phone)
                put("village", f.village)
                put("groupIds", gArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_FARMERS, arr.toString()).apply()
    }

    fun upsertFarmer(context: Context, farmer: FarmerContact) {
        val all = getFarmers(context).toMutableList()
        val norm = normalizePhone(farmer.phone)
        val cleanFarmer = farmer.copy(phone = norm)
        val idxById = all.indexOfFirst { it.id == cleanFarmer.id }
        val idxByPhone = all.indexOfFirst { it.phone == norm }
        when {
            idxById >= 0 -> all[idxById] = cleanFarmer
            idxByPhone >= 0 -> {
                val mergedGroups = (all[idxByPhone].groupIds + cleanFarmer.groupIds).distinct()
                all[idxByPhone] = all[idxByPhone].copy(
                    name = cleanFarmer.name,
                    village = cleanFarmer.village.ifEmpty { all[idxByPhone].village },
                    groupIds = mergedGroups
                )
            }
            else -> all.add(cleanFarmer)
        }
        saveFarmers(context, all)
    }

    fun deleteFarmer(context: Context, farmerId: String) {
        val all = getFarmers(context).filterNot { it.id == farmerId }
        saveFarmers(context, all)
    }

    fun resolveUniqueRecipients(
        context: Context,
        selectedGroupIds: Set<String>,
        selectedFarmerIds: Set<String>
    ): List<FarmerContact> {
        val allFarmers = getFarmers(context)
        return allFarmers.filter { farmer ->
            farmer.id in selectedFarmerIds || farmer.groupIds.any { it in selectedGroupIds }
        }.distinctBy { it.phone }
    }

    // --- MASTER CROP SHEETS ---
    fun getCrops(context: Context): List<CropMasterSheet> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_CROPS, "[]") ?: "[]"
        val list = mutableListOf<CropMasterSheet>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val stages = mutableListOf<CropStageRow>()
                val sArr = o.optJSONArray("stages")
                if (sArr != null) {
                    for (j in 0 until sArr.length()) {
                        val so = sArr.getJSONObject(j)
                        stages.add(
                            CropStageRow(
                                id = so.getString("id"),
                                dayOffset = so.getInt("dayOffset"),
                                stageTitle = so.getString("stageTitle"),
                                messageGujarati = so.getString("messageGujarati")
                            )
                        )
                    }
                }
                list.add(
                    CropMasterSheet(
                        id = o.getString("id"),
                        cropName = o.getString("cropName"),
                        season = o.optString("season", "બારેમાસ"),
                        weatherNote = o.optString("weatherNote", ""),
                        stages = stages.sortedBy { it.dayOffset }
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun getCropById(context: Context, cropId: String): CropMasterSheet? {
        return getCrops(context).firstOrNull { it.id == cropId }
    }

    fun saveCrops(context: Context, crops: List<CropMasterSheet>) {
        val arr = JSONArray()
        for (c in crops) {
            val sArr = JSONArray()
            for (s in c.stages.sortedBy { it.dayOffset }) {
                sArr.put(JSONObject().apply {
                    put("id", s.id)
                    put("dayOffset", s.dayOffset)
                    put("stageTitle", s.stageTitle)
                    put("messageGujarati", s.messageGujarati)
                })
            }
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("cropName", c.cropName)
                put("season", c.season)
                put("weatherNote", c.weatherNote)
                put("stages", sArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_CROPS, arr.toString()).apply()
    }

    fun upsertCrop(context: Context, crop: CropMasterSheet) {
        val all = getCrops(context).toMutableList()
        val idx = all.indexOfFirst { it.id == crop.id }
        if (idx >= 0) all[idx] = crop else all.add(crop)
        saveCrops(context, all)
    }

    fun deleteCrop(context: Context, cropId: String) {
        val all = getCrops(context).filterNot { it.id == cropId }
        saveCrops(context, all)
    }

    fun exportCropSheetCsv(crop: CropMasterSheet): String {
        val sb = StringBuilder()
        sb.append("Day,StageTitle,GujaratiMessage\n")
        for (s in crop.stages.sortedBy { it.dayOffset }) {
            val safeTitle = s.stageTitle.replace("\"", "\"\"")
            val safeMsg = s.messageGujarati.replace("\"", "\"\"").replace("\n", " ")
            sb.append("${s.dayOffset},\"$safeTitle\",\"$safeMsg\"\n")
        }
        return sb.toString()
    }

    fun parseCsvToStageRows(csvText: String): List<CropStageRow> {
        val rows = mutableListOf<CropStageRow>()
        val lines = csvText.lines().filter { it.trim().isNotEmpty() }
        for (line in lines) {
            if (line.trim().startsWith("Day", ignoreCase = true)) continue
            val parts = splitCsvLine(line)
            if (parts.size >= 3) {
                val day = parts[0].trim().toIntOrNull() ?: continue
                val title = parts[1].trim()
                val msg = parts[2].trim()
                if (title.isNotEmpty() && msg.isNotEmpty()) {
                    rows.add(CropStageRow(UUID.randomUUID().toString(), day.coerceAtLeast(0), title, msg))
                }
            }
        }
        return rows.sortedBy { it.dayOffset }
    }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {\n                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++\n                } else {\n                    inQuotes = !inQuotes\n                }
            } else if (ch == ',' && !inQuotes) {\n                result.add(sb.toString())
                sb.clear()
            } else {\n                sb.append(ch)
            }
            i++\n        }
        result.add(sb.toString())
        return result\n    }
\n    // --- LINKED SCHEDULES ---\n    fun getSchedules(context: Context): List<ScheduledAdvisory> {\n        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_SCHEDULES, "[]") ?: "[]"\n        val list = mutableListOf<ScheduledAdvisory>()
        try {\n            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {\n                val o = arr.getJSONObject(i)
                val rIds = mutableListOf<String>()
                val rArr = o.optJSONArray("recipientIds")
                if (rArr != null) {\n                    for (j in 0 until rArr.length()) rIds.add(rArr.getString(j))
                }
                list.add(\n                    ScheduledAdvisory(\n                        id = o.getString("id"),\n                        batchId = o.optString("batchId", ""),\n                        cropId = o.optString("cropId", ""),\n                        cropName = o.getString("cropName"),\n                        sowingDateIso = o.getString("sowingDateIso"),\n                        targetDateIso = o.getString("targetDateIso"),\n                        dayOffset = o.getInt("dayOffset"),\n                        stageTitle = o.getString("stageTitle"),\n                        messageGujarati = o.getString("messageGujarati"),\n                        recipientIds = rIds,\n                        recipientSummary = o.optString("recipientSummary", ""),\n                        repeatYearly = o.optBoolean("repeatYearly", true),\n                        isSent = o.optBoolean("isSent", false),\n                        sentChannel = o.optString("sentChannel", "")
                    )
                )
            }
        } catch (_: Exception) {\n        }
        return list.sortedWith(compareBy<ScheduledAdvisory> { it.isSent }.thenBy { it.targetDateIso })\n    }
\n    fun saveSchedules(context: Context, items: List<ScheduledAdvisory>) {\n        val arr = JSONArray()
        for (s in items) {\n            val rArr = JSONArray()
            s.recipientIds.forEach { rArr.put(it) }
            arr.put(JSONObject().apply {\n                put("id", s.id)
                put("batchId", s.batchId)
                put("cropId", s.cropId)
                put("cropName", s.cropName)
                put("sowingDateIso", s.sowingDateIso)
                put("targetDateIso", s.targetDateIso)
                put("dayOffset", s.dayOffset)
                put("stageTitle", s.stageTitle)
                put("messageGujarati", s.messageGujarati)
                put("recipientIds", rArr)
                put("recipientSummary", s.recipientSummary)
                put("repeatYearly", s.repeatYearly)
                put("isSent", s.isSent)
                put("sentChannel", s.sentChannel)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_SCHEDULES, arr.toString()).apply()\n    }
\n    fun linkCropSheetToRecipients(
        context: Context,
        crop: CropMasterSheet,
        sowingDate: LocalDate,
        recipients: List<FarmerContact>,
        recipientSummary: String,
        repeatYearly: Boolean
    ): Int {
        if (recipients.isEmpty() || crop.stages.isEmpty()) return 0
        val existing = getSchedules(context).toMutableList()
        val batchId = UUID.randomUUID().toString()
        val recIds = recipients.map { it.id }

        for (stage in crop.stages.sortedBy { it.dayOffset }) {
            val targetDate = sowingDate.plusDays(stage.dayOffset.toLong())
            val formattedMsg = buildString {
                append("🌱 *${crop.cropName} પાક સલાહ (દિવસ ${stage.dayOffset})*\n")
                append("📌 અવસ્થા: ${stage.stageTitle}\n")
                append("📅 વાવેતર તારીખ: ${formatDateDisplay(sowingDate.toString())}\n\n")
                append(stage.messageGujarati)
            }
            existing.add(
                ScheduledAdvisory(
                    id = UUID.randomUUID().toString(),
                    batchId = batchId,
                    cropId = crop.id,
                    cropName = crop.cropName,
                    sowingDateIso = sowingDate.toString(),
                    targetDateIso = targetDate.toString(),
                    dayOffset = stage.dayOffset,
                    stageTitle = stage.stageTitle,
                    messageGujarati = formattedMsg,
                    recipientIds = recIds,
                    recipientSummary = recipientSummary,
                    repeatYearly = repeatYearly,
                    isSent = false
                )
            )
        }
        saveSchedules(context, existing)
        return crop.stages.size
    }

    fun markScheduleSent(context: Context, scheduleId: String, channel: String) {\n        val all = getSchedules(context).toMutableList()
        val idx = all.indexOfFirst { it.id == scheduleId }
        if (idx >= 0) {\n            val item = all[idx]\n            all[idx] = item.copy(isSent = true, sentChannel = channel)
            // If repeatYearly is enabled, auto-create next year's occurrence on same date!\n            if (item.repeatYearly) {\n                try {\n                    val nextSowing = LocalDate.parse(item.sowingDateIso).plusYears(1)
                    val nextTarget = LocalDate.parse(item.targetDateIso).plusYears(1)
                    all.add(\n                        item.copy(\n                            id = UUID.randomUUID().toString(),\n                            sowingDateIso = nextSowing.toString(),\n                            targetDateIso = nextTarget.toString(),\n                            isSent = false,\n                            sentChannel = ""\n                        )
                    )
                } catch (_: Exception) {\n                }
            }
            saveSchedules(context, all)
        }
    }
\n    fun deleteSchedule(context: Context, scheduleId: String) {\n        val all = getSchedules(context).filterNot { it.id == scheduleId }
        saveSchedules(context, all)\n    }
\n    // --- APMC YARDS ---\n    fun getApmcYards(context: Context): List<ApmcYard> {\n        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_APMC, "[]") ?: "[]"\n        val list = mutableListOf<ApmcYard>()
        try {\n            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {\n                val o = arr.getJSONObject(i)
                val rates = mutableListOf<ApmcCropRate>()
                val rArr = o.optJSONArray("rates")
                if (rArr != null) {\n                    for (j in 0 until rArr.length()) {\n                        val ro = rArr.getJSONObject(j)
                        rates.add(\n                            ApmcCropRate(\n                                id = ro.getString("id"),\n                                cropName = ro.getString("cropName"),\n                                minPrice = ro.getInt("minPrice"),\n                                maxPrice = ro.getInt("maxPrice")
                            )
                        )
                    }
                }
                list.add(\n                    ApmcYard(\n                        id = o.getString("id"),\n                        yardName = o.getString("yardName"),\n                        updatedDate = o.optString("updatedDate", ""),\n                        rates = rates\n                    )
                )
            }
        } catch (_: Exception) {\n        }
        return list\n    }
\n    fun saveApmcYards(context: Context, yards: List<ApmcYard>) {\n        val arr = JSONArray()
        for (y in yards) {\n            val rArr = JSONArray()
            for (r in y.rates) {\n                rArr.put(JSONObject().apply {\n                    put("id", r.id)
                    put("cropName", r.cropName)
                    put("minPrice", r.minPrice)
                    put("maxPrice", r.maxPrice)
                })
            }
            arr.put(JSONObject().apply {\n                put("id", y.id)
                put("yardName", y.yardName)
                put("updatedDate", y.updatedDate)
                put("rates", rArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_APMC, arr.toString()).apply()\n    }
\n    fun upsertApmcYard(context: Context, yard: ApmcYard) {\n        val all = getApmcYards(context).toMutableList()
        val idx = all.indexOfFirst { it.id == yard.id }
        if (idx >= 0) all[idx] = yard else all.add(yard)
        saveApmcYards(context, all)\n    }
\n    fun deleteApmcYard(context: Context, yardId: String) {\n        val all = getApmcYards(context).filterNot { it.id == yardId }
        saveApmcYards(context, all)\n    }
\n    fun formatApmcMessageGujarati(yard: ApmcYard): String {
        val sb = StringBuilder()
        sb.append("📊 *${yard.yardName} - આજના બજાર ભાવ*\n")
        sb.append("📅 તારીખ: ${yard.updatedDate} (૨૦ કિલો / મણ દીઠ)\n\n")
        for (r in yard.rates) {
            sb.append("• ${r.cropName}: ₹${r.minPrice} થી ₹${r.maxPrice}\n")
        }
        sb.append("\n🙏 ખેડૂત મિત્રો માટે દૈનિક બજાર ભાવ માહિતી")
        return sb.toString()
    }
}
