package com.example.khedutagro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var sectionCrops: View
    private lateinit var sectionFarmers: View
    private lateinit var sectionApmc: View
    private lateinit var sectionWeather: View

    // Tab 1: Crops & Schedule
    private lateinit var chipSubMasterSheets: Chip
    private lateinit var chipSubScheduledQueue: Chip
    private lateinit var recyclerCrops: RecyclerView
    private lateinit var recyclerSchedules: RecyclerView
    private lateinit var tvEmptySchedules: TextView
    private lateinit var cropAdapter: CropMasterAdapter
    private lateinit var scheduleAdapter: ScheduleAdapter

    // Tab 2: Farmers & Groups
    private lateinit var chipGroupFilterContainer: ChipGroup
    private lateinit var recyclerFarmers: RecyclerView
    private lateinit var farmerAdapter: FarmerAdapter
    private var selectedGroupFilterId: String = "ALL"

    // Tab 3: APMC Bajar Bhav
    private lateinit var chipGroupApmcYards: ChipGroup
    private lateinit var tvApmcTitleDate: TextView
    private lateinit var recyclerApmcRates: RecyclerView
    private lateinit var apmcRateAdapter: ApmcRateAdapter
    private var selectedYardId: String = ""

    // Tab 4: Weather
    private lateinit var chipGroupWeatherLoc: ChipGroup
    private lateinit var tvWeatherSummaryCard: TextView
    private lateinit var etWeatherGujMessage: EditText
    private var selectedWeatherLocIdx: Int = 0

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    private val contactPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            openPhoneContactsImporter()
        } else {
            Toast.makeText(this, "Phone contacts import karva permission jaroori chhe", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root: View = findViewById(R.id.agroRootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        requestCorePermissions()

        sectionCrops = findViewById(R.id.sectionCrops)
        sectionFarmers = findViewById(R.id.sectionFarmers)
        sectionApmc = findViewById(R.id.sectionApmc)
        sectionWeather = findViewById(R.id.sectionWeather)

        setupTab1CropsAndSchedules()
        setupTab2FarmersAndGroups()
        setupTab3ApmcBajarBhav()
        setupTab4WeatherAdvisory()

        val bottomNav: BottomNavigationView = findViewById(R.id.bottomNavAgro)
        bottomNav.setOnItemSelectedListener { item ->
            sectionCrops.visibility = if (item.itemId == R.id.nav_pak) View.VISIBLE else View.GONE
            sectionFarmers.visibility = if (item.itemId == R.id.nav_khedut) View.VISIBLE else View.GONE
            sectionApmc.visibility = if (item.itemId == R.id.nav_apmc) View.VISIBLE else View.GONE
            sectionWeather.visibility = if (item.itemId == R.id.nav_weather) View.VISIBLE else View.GONE
            refreshAllTabs()
            true
        }

        AgroRepository.ensureSeeded(this)
        DailyDueReceiver.scheduleDailyMorningCheck(this)
        refreshAllTabs()
        loadLiveWeather()
    }

    override fun onResume() {
        super.onResume()
        refreshAllTabs()
    }

    private fun requestCorePermissions() {
        val needed = mutableListOf(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    // =========================================================
    // TAB 1: PAK MASTER SHEETS & LINKED SCHEDULE QUEUE
    // =========================================================
    private fun setupTab1CropsAndSchedules() {
        chipSubMasterSheets = findViewById(R.id.chipSubMasterSheets)
        chipSubScheduledQueue = findViewById(R.id.chipSubScheduledQueue)
        recyclerCrops = findViewById(R.id.recyclerCrops)
        recyclerSchedules = findViewById(R.id.recyclerSchedules)
        tvEmptySchedules = findViewById(R.id.tvEmptySchedules)

        recyclerCrops.layoutManager = LinearLayoutManager(this)
        cropAdapter = CropMasterAdapter(
            crops = emptyList(),
            onOpenSheet = { crop ->
                val intent = Intent(this, CropSheetDetailActivity::class.java).apply {
                    putExtra(CropSheetDetailActivity.EXTRA_CROP_ID, crop.id)
                    putExtra(CropSheetDetailActivity.EXTRA_AUTO_LINK, false)
                }
                startActivity(intent)
            },
            onLinkSheet = { crop ->
                val intent = Intent(this, CropSheetDetailActivity::class.java).apply {
                    putExtra(CropSheetDetailActivity.EXTRA_CROP_ID, crop.id)
                    putExtra(CropSheetDetailActivity.EXTRA_AUTO_LINK, true)
                }
                startActivity(intent)
            },
            onDeleteCrop = { crop ->
                AlertDialog.Builder(this)
                    .setTitle("${crop.cropName} Delete Karvu Chhe?")
                    .setMessage("Aa pak ni master sheet hamesha mate delete thai jase.")
                    .setPositiveButton("Delete") { _, _ ->
                        AgroRepository.deleteCrop(this, crop.id)
                        refreshAllTabs()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        recyclerCrops.adapter = cropAdapter

        recyclerSchedules.layoutManager = LinearLayoutManager(this)
        scheduleAdapter = ScheduleAdapter(
            items = emptyList(),
            onSendSms = { sched ->
                val recipients = resolveScheduleRecipients(sched)
                MessageSenderHelper.confirmAndSendSms(this, recipients, sched.messageGujarati) {
                    AgroRepository.markScheduleSent(this, sched.id, "SMS")
                    refreshAllTabs()
                }
            },
            onSendWhatsApp = { sched ->
                val recipients = resolveScheduleRecipients(sched)
                MessageSenderHelper.startWhatsAppGuidedQueue(this, recipients, sched.messageGujarati) {
                    AgroRepository.markScheduleSent(this, sched.id, "WhatsApp")
                    refreshAllTabs()
                }
            },
            onDeleteSchedule = { sched ->
                AgroRepository.deleteSchedule(this, sched.id)
                refreshAllTabs()
            }
        )
        recyclerSchedules.adapter = scheduleAdapter

        chipSubMasterSheets.setOnClickListener {
            recyclerCrops.visibility = View.VISIBLE
            recyclerSchedules.visibility = View.GONE
            tvEmptySchedules.visibility = View.GONE
        }

        chipSubScheduledQueue.setOnClickListener {
            recyclerCrops.visibility = View.GONE
            recyclerSchedules.visibility = View.VISIBLE
            refreshAllTabs()
        }

        findViewById<MaterialButton>(R.id.btnAddNewCrop).setOnClickListener {
            showAddCropDialog()
        }
    }

    private fun resolveScheduleRecipients(sched: ScheduledAdvisory): List<FarmerContact> {
        val allFarmers = AgroRepository.getFarmers(this)
        return allFarmers.filter { it.id in sched.recipientIds }
    }

    private fun showAddCropDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_crop, null)
        val etName: EditText = v.findViewById(R.id.etCropNameInput)
        val etSeason: EditText = v.findViewById(R.id.etCropSeasonInput)
        val etWeather: EditText = v.findViewById(R.id.etCropWeatherInput)

        AlertDialog.Builder(this)
            .setTitle("નવો પાક (New Crop Sheet) ઉમેરો")
            .setView(v)
            .setPositiveButton("Create Sheet") { _, _ ->
                val name = etName.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "પાકનું નામ લખો", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val newCrop = CropMasterSheet(
                    id = UUID.randomUUID().toString(),
                    cropName = name,
                    season = etSeason.text.toString().trim().ifEmpty { "શિયાળુ / ચોમાસુ" },
                    weatherNote = etWeather.text.toString().trim(),
                    stages = listOf(
                        CropStageRow(
                            UUID.randomUUID().toString(),
                            0,
                            "વાવેતર અને પ્રારંભિક કાળજી",
                            "નમસ્તે ખેડૂત મિત્ર, $name ના વાવેતર બાદ યોગ્ય પિયત અને પાયાના ખાતરની કાળજી લેવી."
                        )
                    )
                )
                AgroRepository.upsertCrop(this, newCrop)
                refreshAllTabs()
                val intent = Intent(this, CropSheetDetailActivity::class.java).apply {
                    putExtra(CropSheetDetailActivity.EXTRA_CROP_ID, newCrop.id)
                }
                startActivity(intent)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================
    // TAB 2: KHEDUT CONTACTS & GROUPS
    // =========================================================
    private fun setupTab2FarmersAndGroups() {
        chipGroupFilterContainer = findViewById(R.id.chipGroupFilterContainer)
        recyclerFarmers = findViewById(R.id.recyclerFarmers)

        recyclerFarmers.layoutManager = LinearLayoutManager(this)
        farmerAdapter = FarmerAdapter(
            farmers = emptyList(),
            groups = emptyList(),
            onEditFarmer = { farmer -> showAddOrEditFarmerDialog(farmer) },
            onDeleteFarmer = { farmer ->
                AgroRepository.deleteFarmer(this, farmer.id)
                refreshAllTabs()
            }
        )
        recyclerFarmers.adapter = farmerAdapter

        findViewById<MaterialButton>(R.id.btnImportPhoneContacts).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                openPhoneContactsImporter()
            } else {
                contactPermLauncher.launch(Manifest.permission.READ_CONTACTS)
            }
        }

        findViewById<MaterialButton>(R.id.btnAddFarmerManual).setOnClickListener {
            showAddOrEditFarmerDialog(null)
        }

        findViewById<MaterialButton>(R.id.btnManageGroups).setOnClickListener {
            showManageGroupsDialog()
        }

        findViewById<MaterialButton>(R.id.btnSendCustomMessage).setOnClickListener {
            showCustomMessageComposerDialog()
        }
    }

    private fun openPhoneContactsImporter() {
        val rawContacts = mutableListOf<Pair<String, String>>()
        val seen = mutableSetOf<String>()
        try {
            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )
            cursor?.use {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val name = it.getString(nameIdx)?.trim() ?: continue
                    val num = AgroRepository.normalizePhone(it.getString(numIdx) ?: "")
                    if (num.length == 10 && num !in seen) {
                        seen.add(num)
                        rawContacts.add(name to num)
                    }
                }
            }
        } catch (_: Exception) {
        }

        if (rawContacts.isEmpty()) {
            Toast.makeText(this, "Phone ma koi 10-digit contact mali nathi", Toast.LENGTH_SHORT).show()
            return
        }

        val v = LayoutInflater.from(this).inflate(R.layout.dialog_import_contacts, null)
        val etSearch: EditText = v.findViewById(R.id.etSearchPhoneContact)
        val rvPick: RecyclerView = v.findViewById(R.id.rvPhoneContacts)
        val containerAssignGroups: LinearLayout = v.findViewById(R.id.containerAssignGroupsOnImport)

        val groups = AgroRepository.getGroups(this)
        val assignGroupIds = mutableSetOf<String>()
        for (g in groups) {
            val cb = CheckBox(this).apply {
                text = g.name
                setOnCheckedChangeListener { _, checked ->
                    if (checked) assignGroupIds.add(g.id) else assignGroupIds.remove(g.id)
                }
            }
            containerAssignGroups.addView(cb)
        }

        val selectedPhones = mutableSetOf<String>()
        val pickAdapter = PhoneContactPickAdapter(rawContacts, selectedPhones)
        rvPick.layoutManager = LinearLayoutManager(this)
        rvPick.adapter = pickAdapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s.toString().trim().lowercase(Locale.getDefault())
                val filtered = if (q.isEmpty()) {
                    rawContacts
                } else {
                    rawContacts.filter { it.first.lowercase(Locale.getDefault()).contains(q) || it.second.contains(q) }
                }
                pickAdapter.updateItems(filtered)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        AlertDialog.Builder(this)
            .setTitle("Phone Contacts Import Karo")
            .setView(v)
            .setPositiveButton("Import Selected") { _, _ ->
                var added = 0
                for ((name, phone) in rawContacts) {
                    if (phone in selectedPhones) {
                        AgroRepository.upsertFarmer(
                            this,
                            FarmerContact(
                                id = UUID.randomUUID().toString(),
                                name = name,
                                phone = phone,
                                groupIds = assignGroupIds.toList()
                            )
                        )
                        added++
                    }
                }
                refreshAllTabs()
                Toast.makeText(this, "$added khedut contacts add thai gaya!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddOrEditFarmerDialog(existing: FarmerContact?) {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_farmer, null)
        val etName: EditText = v.findViewById(R.id.etFarmerNameInput)
        val etPhone: EditText = v.findViewById(R.id.etFarmerPhoneInput)
        val etVillage: EditText = v.findViewById(R.id.etFarmerVillageInput)
        val containerGroups: LinearLayout = v.findViewById(R.id.containerFarmerGroupsCheck)

        if (existing != null) {
            etName.setText(existing.name)
            etPhone.setText(existing.phone)
            etVillage.setText(existing.village)
        }

        val groups = AgroRepository.getGroups(this)
        val chosenGroups = mutableSetOf<String>()
        if (existing != null) chosenGroups.addAll(existing.groupIds)

        for (g in groups) {
            val cb = CheckBox(this).apply {
                text = g.name
                isChecked = g.id in chosenGroups
                setOnCheckedChangeListener { _, checked ->
                    if (checked) chosenGroups.add(g.id) else chosenGroups.remove(g.id)
                }
            }
            containerGroups.addView(cb)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "નવો ખેડૂત ઉમેરો" else "ખેડૂત વિગત સુધારો")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val phone = AgroRepository.normalizePhone(etPhone.text.toString())
                if (name.isEmpty() || phone.length != 10) {
                    Toast.makeText(this, "Khedut nu naam ane 10-digit mobile number lakho", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val item = FarmerContact(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    phone = phone,
                    village = etVillage.text.toString().trim(),
                    groupIds = chosenGroups.toList()
                )
                AgroRepository.upsertFarmer(this, item)
                refreshAllTabs()
                Toast.makeText(this, "Khedut save thai gayo!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showManageGroupsDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_manage_groups, null)
        val etNewGroupName: EditText = v.findViewById(R.id.etNewGroupName)
        val containerExisting: LinearLayout = v.findViewById(R.id.containerExistingGroupsList)

        fun renderGroupsList() {
            containerExisting.removeAllViews()
            val groups = AgroRepository.getGroups(this)
            for (g in groups) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, 8, 0, 8)
                }
                val tv = TextView(this).apply {
                    text = g.name
                    textSize = 15f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val btnDel = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = "Delete"
                    setOnClickListener {
                        AgroRepository.deleteGroup(this@MainActivity, g.id)
                        if (selectedGroupFilterId == g.id) selectedGroupFilterId = "ALL"
                        renderGroupsList()
                        refreshAllTabs()
                    }
                }
                row.addView(tv)
                row.addView(btnDel)
                containerExisting.addView(row)
            }
        }

        renderGroupsList()

        AlertDialog.Builder(this)
            .setTitle("Groups Add / Delete Karo")
            .setView(v)
            .setPositiveButton("Add Group") { _, _ ->
                val name = etNewGroupName.text.toString().trim()
                if (name.isNotEmpty()) {
                    AgroRepository.addGroup(this, name, "")
                    refreshAllTabs()
                    Toast.makeText(this, "Group '$name' bani gayu!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showCustomMessageComposerDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_custom_message, null)
        val etMsg: EditText = v.findViewById(R.id.etCustomGujaratiMessage)

        v.findViewById<Chip>(R.id.chipQuickTplCrop).setOnClickListener {
            etMsg.setText("🌱 *પાક સંરક્ષણ સલાહ*\nનમસ્તે ખેડૂત મિત્ર, હાલના વાતાવરણમાં પાકમાં ચૂસિયા જીવાત અને ફૂગના નિયંત્રણ માટે ભલામણ મુજબ દવાનો છંટકાવ કરવો.")
        }
        v.findViewById<Chip>(R.id.chipQuickTplWeather).setOnClickListener {
            etMsg.setText("🌦️ *હવામાન ચેતવણી*\nખેડૂત મિત્રો, આગામી ૨ દિવસ વાદળછાયું વાતાવરણ રહેવાની શક્યતા હોવાથી કાપણી કરેલ પાક સુરક્ષિત જગ્યાએ રાખવો.")
        }
        v.findViewById<Chip>(R.id.chipQuickTplCondition).setOnClickListener {
            etMsg.setText("🌾 *પાકની પરિસ્થિતિ અને ખાતર*\nપાકની સારી વૃદ્ધિ માટે સમયસર પિયત અને સૂક્ષ્મ પોષક તત્વોનો છંટકાવ કરવા વિનંતી.")
        }

        AlertDialog.Builder(this)
            .setTitle("ગુજરાતી સંદેશ મોકલો (Personal / Group)")
            .setView(v)
            .setPositiveButton("Text SMS Moklo") { _, _ ->
                val text = etMsg.text.toString().trim()
                if (text.isEmpty()) return@setPositiveButton
                RecipientPickerDialog.show(this, "Text SMS કોને મોકલવો છે?") { recipients, _ ->
                    MessageSenderHelper.confirmAndSendSms(this, recipients, text)
                }
            }
            .setNeutralButton("WhatsApp Moklo") { _, _ ->
                val text = etMsg.text.toString().trim()
                if (text.isEmpty()) return@setNeutralButton
                RecipientPickerDialog.show(this, "WhatsApp કોને મોકલવો છે?") { recipients, _ ->
                    MessageSenderHelper.startWhatsAppGuidedQueue(this, recipients, text)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================
    // TAB 3: APMC BAJAR BHAV (MORBI, RAJKOT + ADD/DELETE YARDS)
    // =========================================================
    private fun setupTab3ApmcBajarBhav() {
        chipGroupApmcYards = findViewById(R.id.chipGroupApmcYards)
        tvApmcTitleDate = findViewById(R.id.tvApmcTitleDate)
        recyclerApmcRates = findViewById(R.id.recyclerApmcRates)

        recyclerApmcRates.layoutManager = LinearLayoutManager(this)
        apmcRateAdapter = ApmcRateAdapter(
            rates = emptyList(),
            onEditRate = { rate -> showAddOrEditRateDialog(rate) },
            onDeleteRate = { rate ->
                val yard = getSelectedYard() ?: return@ApmcRateAdapter
                val updatedRates = yard.rates.filterNot { it.id == rate.id }
                AgroRepository.upsertApmcYard(this, yard.copy(rates = updatedRates))
                refreshAllTabs()
            }
        )
        recyclerApmcRates.adapter = apmcRateAdapter

        findViewById<MaterialButton>(R.id.btnAddApmcYard).setOnClickListener {
            val input = EditText(this).apply {
                hint = "e.g. ગોંડલ APMC / ઊંઝા APMC"
                setPadding(40, 28, 40, 28)
            }
            AlertDialog.Builder(this)
                .setTitle("નવું APMC માર્કેટિંગ યાર્ડ ઉમેરો")
                .setView(input)
                .setPositiveButton("Add") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) {
                        val todayStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
                        val newYard = ApmcYard(
                            id = UUID.randomUUID().toString(),
                            yardName = name,
                            updatedDate = todayStr,
                            rates = listOf(ApmcCropRate(UUID.randomUUID().toString(), "જીરું", 4200, 4600))
                        )
                        AgroRepository.upsertApmcYard(this, newYard)
                        selectedYardId = newYard.id
                        refreshAllTabs()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnDeleteApmcYard).setOnClickListener {
            val yard = getSelectedYard() ?: return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("${yard.yardName} Delete Karvu Chhe?")
                .setPositiveButton("Delete") { _, _ ->
                    AgroRepository.deleteApmcYard(this, yard.id)
                    selectedYardId = ""
                    refreshAllTabs()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnAddCropRate).setOnClickListener {
            showAddOrEditRateDialog(null)
        }

        // Strict Targeted Send: Sends ONLY to user-selected farmers/groups!
        findViewById<MaterialButton>(R.id.btnSendBhavSms).setOnClickListener {
            val yard = getSelectedYard() ?: return@setOnClickListener
            val msg = AgroRepository.formatApmcMessageGujarati(yard)
            RecipientPickerDialog.show(
                this,
                "${yard.yardName} ના ભાવ - કોને Text SMS મોકલવો? (બીજા કોઈને નહીં જાય)"
            ) { recipients, _ ->
                MessageSenderHelper.confirmAndSendSms(this, recipients, msg)
            }
        }

        findViewById<MaterialButton>(R.id.btnSendBhavWhatsApp).setOnClickListener {
            val yard = getSelectedYard() ?: return@setOnClickListener
            val msg = AgroRepository.formatApmcMessageGujarati(yard)
            RecipientPickerDialog.show(
                this,
                "${yard.yardName} ના ભાવ - કોને WhatsApp મોકલવો? (બીજા કોઈને નહીં જાય)"
            ) { recipients, _ ->
                MessageSenderHelper.startWhatsAppGuidedQueue(this, recipients, msg)
            }
        }
    }

    private fun getSelectedYard(): ApmcYard? {
        val yards = AgroRepository.getApmcYards(this)
        if (yards.isEmpty()) return null
        return yards.firstOrNull { it.id == selectedYardId } ?: yards.first().also { selectedYardId = it.id }
    }

    private fun showAddOrEditRateDialog(existing: ApmcCropRate?) {
        val yard = getSelectedYard() ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_rate, null)
        val etCrop: EditText = v.findViewById(R.id.etRateCropInput)
        val etMin: EditText = v.findViewById(R.id.etRateMinInput)
        val etMax: EditText = v.findViewById(R.id.etRateMaxInput)

        if (existing != null) {
            etCrop.setText(existing.cropName)
            etMin.setText(existing.minPrice.toString())
            etMax.setText(existing.maxPrice.toString())
        }

        AlertDialog.Builder(this)
            .setTitle("${yard.yardName} - ભાવ ઉમેરો / સુધારો")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val cName = etCrop.text.toString().trim()
                val minP = etMin.text.toString().trim().toIntOrNull() ?: 0
                val maxP = etMax.text.toString().trim().toIntOrNull() ?: 0
                if (cName.isEmpty() || minP <= 0 || maxP <= 0) {
                    Toast.makeText(this, "પાકનું નામ અને સાચો ભાવ લખો", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val list = yard.rates.toMutableList()
                if (existing != null) {
                    val idx = list.indexOfFirst { it.id == existing.id }
                    if (idx >= 0) list[idx] = existing.copy(cropName = cName, minPrice = minP, maxPrice = maxP)
                } else {
                    list.add(ApmcCropRate(UUID.randomUUID().toString(), cName, minP, maxP))
                }
                val todayStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
                AgroRepository.upsertApmcYard(this, yard.copy(updatedDate = todayStr, rates = list))
                refreshAllTabs()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================
    // TAB 4: LIVE WEATHER ADVISORY
    // =========================================================
    private fun setupTab4WeatherAdvisory() {
        chipGroupWeatherLoc = findViewById(R.id.chipGroupWeatherLoc)
        tvWeatherSummaryCard = findViewById(R.id.tvWeatherSummaryCard)
        etWeatherGujMessage = findViewById(R.id.etWeatherGujMessage)

        chipGroupWeatherLoc.removeAllViews()
        WeatherService.LOCATIONS.forEachIndexed { idx, loc ->
            val chip = Chip(this).apply {
                text = loc.name
                isCheckable = true
                isChecked = (idx == selectedWeatherLocIdx)
                setOnClickListener {
                    selectedWeatherLocIdx = idx
                    loadLiveWeather()
                }
            }
            chipGroupWeatherLoc.addView(chip)
        }

        findViewById<MaterialButton>(R.id.btnRefreshWeather).setOnClickListener {
            loadLiveWeather()
        }

        findViewById<MaterialButton>(R.id.btnSendWeatherSms).setOnClickListener {
            val msg = etWeatherGujMessage.text.toString().trim()
            RecipientPickerDialog.show(this, "હવામાન સલાહ - કોને Text SMS મોકલવો?") { recipients, _ ->
                MessageSenderHelper.confirmAndSendSms(this, recipients, msg)
            }
        }

        findViewById<MaterialButton>(R.id.btnSendWeatherWa).setOnClickListener {
            val msg = etWeatherGujMessage.text.toString().trim()
            RecipientPickerDialog.show(this, "હવામાન સલાહ - કોને WhatsApp મોકલવો?") { recipients, _ ->
                MessageSenderHelper.startWhatsAppGuidedQueue(this, recipients, msg)
            }
        }
    }

    private fun loadLiveWeather() {
        val loc = WeatherService.LOCATIONS.getOrElse(selectedWeatherLocIdx) { WeatherService.LOCATIONS.first() }
        tvWeatherSummaryCard.text = "${loc.name} નું લાઈવ હવામાન લોડ થઈ રહ્યું છે..."
        lifecycleScope.launch {
            val info = WeatherService.fetchLiveWeather(loc)
            tvWeatherSummaryCard.text =
                "📍 ${info.locationName}\n" +
                    "🌡️ તાપમાન: ${info.tempC}°C (Max ${info.maxTempC}°C / Min ${info.minTempC}°C)\n" +
                    "💧 ભેજ: ${info.humidity}%  |  💨 પવન: ${info.windKmh} km/h  |  🌧️ વરસાદ: ${info.rainProbPercent}%"
            etWeatherGujMessage.setText(info.gujaratiAdvisoryMessage)
        }
    }

    // =========================================================
    // REFRESH ALL UI
    // =========================================================
    private fun refreshAllTabs() {
        // Tab 1
        val crops = AgroRepository.getCrops(this)
        cropAdapter.updateList(crops)

        val schedules = AgroRepository.getSchedules(this)
        val pendingCount = schedules.count { !it.isSent }
        chipSubScheduledQueue.text = "Scheduled ($pendingCount)"
        scheduleAdapter.updateList(schedules)
        if (recyclerSchedules.visibility == View.VISIBLE) {
            tvEmptySchedules.visibility = if (schedules.isEmpty()) View.VISIBLE else View.GONE
        }

        // Tab 2
        val groups = AgroRepository.getGroups(this)
        val allFarmers = AgroRepository.getFarmers(this)
        chipGroupFilterContainer.removeAllViews()
        val allChip = Chip(this).apply {
            text = "બધા (${allFarmers.size})"
            isCheckable = true
            isChecked = (selectedGroupFilterId == "ALL")
            setOnClickListener { selectedGroupFilterId = "ALL"; refreshAllTabs() }
        }
        chipGroupFilterContainer.addView(allChip)

        for (g in groups) {
            val cnt = allFarmers.count { g.id in it.groupIds }
            val gChip = Chip(this).apply {
                text = "${g.name} ($cnt)"
                isCheckable = true
                isChecked = (selectedGroupFilterId == g.id)
                setOnClickListener { selectedGroupFilterId = g.id; refreshAllTabs() }
            }
            chipGroupFilterContainer.addView(gChip)
        }

        val filteredFarmers = if (selectedGroupFilterId == "ALL") {
            allFarmers
        } else {
            allFarmers.filter { selectedGroupFilterId in it.groupIds }
        }
        farmerAdapter.updateData(filteredFarmers, groups)

        // Tab 3
        val yards = AgroRepository.getApmcYards(this)
        val currentYard = getSelectedYard()
        chipGroupApmcYards.removeAllViews()
        for (y in yards) {
            val yChip = Chip(this).apply {
                text = y.yardName
                isCheckable = true
                isChecked = (currentYard?.id == y.id)
                setOnClickListener {
                    selectedYardId = y.id
                    refreshAllTabs()
                }
            }
            chipGroupApmcYards.addView(yChip)
        }
        if (currentYard != null) {
            tvApmcTitleDate.text = "${currentYard.yardName} • તારીખ: ${currentYard.updatedDate}"
            apmcRateAdapter.updateRates(currentYard.rates)
        } else {
            tvApmcTitleDate.text = "Koi APMC yard nathi — '+ APMC' thi add karo"
            apmcRateAdapter.updateRates(emptyList())
        }
    }
}
