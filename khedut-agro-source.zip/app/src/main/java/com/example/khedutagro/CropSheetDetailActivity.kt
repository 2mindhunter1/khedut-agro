package com.example.khedutagro

import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class CropSheetDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CROP_ID = "extra_crop_id"
        const val EXTRA_AUTO_LINK = "extra_auto_link"
    }

    private lateinit var tvSheetHeaderTitle: TextView
    private lateinit var tvSheetSubInfo: TextView
    private lateinit var recyclerStages: RecyclerView
    private lateinit var stageAdapter: StageRowAdapter

    private var cropId: String = ""
    private var currentCrop: CropMasterSheet? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop_sheet_detail)

        val root: View = findViewById(R.id.sheetDetailRoot)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        cropId = intent.getStringExtra(EXTRA_CROP_ID) ?: ""
        val autoLink = intent.getBooleanExtra(EXTRA_AUTO_LINK, false)

        tvSheetHeaderTitle = findViewById(R.id.tvSheetHeaderTitle)
        tvSheetSubInfo = findViewById(R.id.tvSheetSubInfo)
        recyclerStages = findViewById(R.id.recyclerStages)

        findViewById<MaterialButton>(R.id.btnBackSheet).setOnClickListener { finish() }

        recyclerStages.layoutManager = LinearLayoutManager(this)
        stageAdapter = StageRowAdapter(
            stages = emptyList(),
            onEditStage = { row -> showAddOrEditStageDialog(row) },
            onDeleteStage = { row -> deleteStageRow(row) }
        )
        recyclerStages.adapter = stageAdapter

        findViewById<MaterialButton>(R.id.btnAddStageRow).setOnClickListener {
            showAddOrEditStageDialog(null)
        }

        findViewById<MaterialButton>(R.id.btnEditCropMeta).setOnClickListener {
            showEditCropInfoDialog()
        }

        findViewById<MaterialButton>(R.id.btnCsvSheet).setOnClickListener {
            showCsvImportExportDialog()
        }

        findViewById<MaterialButton>(R.id.btnLinkThisSheet).setOnClickListener {
            startLinkSheetWizard()
        }

        reloadCrop()

        if (autoLink && currentCrop != null) {
            startLinkSheetWizard()
        }
    }

    private fun reloadCrop() {
        currentCrop = AgroRepository.getCropById(this, cropId)
        val c = currentCrop
        if (c == null) {
            finish()
            return
        }
        tvSheetHeaderTitle.text = "${c.cropName} - Master Sheet"
        tvSheetSubInfo.text = "${c.season} • કુલ ${c.stages.size} તબક્કા (Stages)"
        stageAdapter.updateStages(c.stages)
    }

    private fun showAddOrEditStageDialog(existing: CropStageRow?) {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_stage, null)
        val etDay: EditText = v.findViewById(R.id.etStageDay)
        val etTitle: EditText = v.findViewById(R.id.etStageTitleInput)
        val etMsg: EditText = v.findViewById(R.id.etStageMessageGuj)

        if (existing != null) {
            etDay.setText(existing.dayOffset.toString())
            etTitle.setText(existing.stageTitle)
            etMsg.setText(existing.messageGujarati)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "નવો તબક્કો (Stage) ઉમેરો" else "તબક્કો (Stage) સુધારો")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val dayVal = (etDay.text.toString().trim().toIntOrNull() ?: 0).coerceAtLeast(0)
                val titleVal = etTitle.text.toString().trim()
                val msgVal = etMsg.text.toString().trim()
                if (titleVal.isEmpty() || msgVal.isEmpty()) {
                    Toast.makeText(this, "અવસ્થા અને ગુજરાતી સંદેશ બંને લખવા જરૂરી છે", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val list = c.stages.toMutableList()
                if (existing != null) {
                    val idx = list.indexOfFirst { it.id == existing.id }
                    if (idx >= 0) {
                        list[idx] = existing.copy(dayOffset = dayVal, stageTitle = titleVal, messageGujarati = msgVal)
                    }
                } else {
                    list.add(CropStageRow(UUID.randomUUID().toString(), dayVal, titleVal, msgVal))
                }
                AgroRepository.upsertCrop(this, c.copy(stages = list.sortedBy { it.dayOffset }))
                reloadCrop()
                Toast.makeText(this, "Sheet update thai gayi!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteStageRow(row: CropStageRow) {
        val c = currentCrop ?: return
        AlertDialog.Builder(this)
            .setTitle("આ તબક્કો Delete કરવો છે?")
            .setMessage("દિવસ ${row.dayOffset}: ${row.stageTitle}")
            .setPositiveButton("Delete") { _, _ ->
                val updated = c.stages.filterNot { it.id == row.id }
                AgroRepository.upsertCrop(this, c.copy(stages = updated))
                reloadCrop()
                Toast.makeText(this, "Stage delete thayu", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditCropInfoDialog() {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_crop, null)
        val etName: EditText = v.findViewById(R.id.etCropNameInput)
        val etSeason: EditText = v.findViewById(R.id.etCropSeasonInput)
        val etWeather: EditText = v.findViewById(R.id.etCropWeatherInput)

        etName.setText(c.cropName)
        etSeason.setText(c.season)
        etWeather.setText(c.weatherNote)

        AlertDialog.Builder(this)
            .setTitle("પાકની વિગત સુધારો")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val n = etName.text.toString().trim()
                if (n.isNotEmpty()) {
                    AgroRepository.upsertCrop(
                        this,
                        c.copy(
                            cropName = n,
                            season = etSeason.text.toString().trim().ifEmpty { c.season },
                            weatherNote = etWeather.text.toString().trim()
                        )
                    )
                    reloadCrop()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCsvImportExportDialog() {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_csv_sheet, null)
        val etCsv: EditText = v.findViewById(R.id.etCsvContent)
        etCsv.setText(AgroRepository.exportCropSheetCsv(c))

        AlertDialog.Builder(this)
            .setTitle("CSV Sheet Import / Export")
            .setView(v)
            .setPositiveButton("Import & Replace Rows") { _, _ ->
                val parsed = AgroRepository.parseCsvToStageRows(etCsv.text.toString())
                if (parsed.isEmpty()) {
                    Toast.makeText(this, "Valid CSV rows mali nathi", Toast.LENGTH_SHORT).show()
                } else {
                    AgroRepository.upsertCrop(this, c.copy(stages = parsed))
                    reloadCrop()
                    Toast.makeText(this, "${parsed.size} stages import thai gaya!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Copy CSV") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CropSheetCSV", etCsv.text.toString()))
                Toast.makeText(this, "CSV copy thai gayo!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun startLinkSheetWizard() {
        val c = currentCrop ?: return
        if (c.stages.isEmpty()) {
            Toast.makeText(this, "Pehla sheet ma kam se kam 1 stage row add karo!", Toast.LENGTH_SHORT).show()
            return
        }

        val today = LocalDate.now()
        DatePickerDialog(
            this,
            { _, y, m, d ->
                val sowingDate = LocalDate.of(y, m + 1, d)
                val dateDisp = sowingDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
                RecipientPickerDialog.show(
                    this,
                    title = "${c.cropName} (વાવેતર: $dateDisp) - કોને લિંક કરવું?"
                ) { recipients, summary ->
                    val cbYearly = CheckBox(this).apply {
                        text = "દર વર્ષે આ જ તારીખે ઓટોમેટિક રિપીટ કરો (Yearly Auto-Repeat)"
                        isChecked = true
                        setPadding(36, 24, 36, 12)
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Schedule Confirm Karo")
                        .setMessage(
                            "પાક: ${c.cropName} (${c.stages.size} તબક્કા)\n" +
                                "વાવેતર તારીખ: $dateDisp\n" +
                                "પસંદ કરેલ: $summary"
                        )
                        .setView(cbYearly)
                        .setPositiveButton("Schedule Banavo") { _, _ ->
                            val count = AgroRepository.linkCropSheetToRecipients(
                                context = this,
                                crop = c,
                                sowingDate = sowingDate,
                                recipients = recipients,
                                recipientSummary = summary,
                                repeatYearly = cbYearly.isChecked
                            )
                            Toast.makeText(
                                this,
                                "$count તબક્કાનું શેડ્યૂલ બની ગયું! Main Screen par 'Scheduled' ma jovo.",
                                Toast.LENGTH_LONG
                            ).show()
                            finish()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            },
            today.year,
            today.monthValue - 1,
            today.dayOfMonth
        ).apply {
            setTitle("વાવેતર તારીખ (Sowing Date) પસંદ કરો")
        }.show()
    }
}
