package com.example.rajalagro

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class AutoAdvisoryAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "rajal_agro_auto_advisory_v2"

        fun scheduleDailyAutoCheck(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val zone = ZoneId.systemDefault()
            val (hour, minute) = AgroRepository.getAutoSendTime(context)
            val now = LocalDateTime.now(zone)
            var nextRun = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
            if (!nextRun.isAfter(now)) {
                nextRun = nextRun.plusDays(1)
            }
            val triggerMillis = nextRun.atZone(zone).toInstant().toEpochMilli()
            val intent = Intent(context, AutoAdvisoryAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                9090,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            } catch (_: Exception) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        // 1. Re-schedule tomorrow's exact alarm
        scheduleDailyAutoCheck(context)

        // 2. Sync all per-farmer sowing dates & any newly added sheet stages
        val autoSentCount = AgroRepository.processDueSchedulesAutomatically(context)
        val todayIso = LocalDate.now().toString()
        val remainingDue = AgroRepository.getSchedules(context).count { !it.isSent && it.targetDateIso <= todayIso }

        if (autoSentCount > 0 || remainingDue > 0) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "રાજલ એગ્રો ઓટો સલાહ", NotificationManager.IMPORTANCE_HIGH)
                )
            }

            val openPi = PendingIntent.getActivity(
                context,
                9091,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val title = if (autoSentCount > 0) {
                "રાજલ એગ્રો: $autoSentCount ખેડૂતોને આજના પાક સલાહ SMS ઓટોમેટિક મોકલાયા"
            } else {
                "રાજલ એગ્રો: $remainingDue પાક સલાહ મેસેજ મોકલવાના બાકી છે"
            }

            val body = if (remainingDue > 0) {
                "બાકી રહેલા $remainingDue મેસેજ WhatsApp કે SMS દ્વારા મોકલવા એપ ખોલો."
            } else {
                "દરેક ખેડૂતની વાવણી તારીખ મુજબ આજના બધા સંદેશ મોકલાઈ ગયા છે."
            }

            val notif = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openPi)
                .build()

            nm.notify(9092, notif)
        }
    }
}
