package com.example.rajalagro

import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class CropSheetDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CROP_ID = "extra_crop_id"
        const val EXTRA_AUTO_LINK = "extra_auto_link"
    }

    private lateinit var tvSheetHeaderTitle: TextView
    private lateinit var tvSheetSubInfo: TextView
    private lateinit var recyclerStages: RecyclerView
    private lateinit var stageAdapter: StageRowAdapter

    private var cropId: String = ""
    private var currentCrop: CropMasterSheet? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop_sheet_detail)

        val root: View = findViewById(R.id.sheetDetailRoot)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        cropId = intent.getStringExtra(EXTRA_CROP_ID) ?: ""
        val autoLink = intent.getBooleanExtra(EXTRA_AUTO_LINK, false)

        tvSheetHeaderTitle = findViewById(R.id.tvSheetHeaderTitle)
        tvSheetSubInfo = findViewById(R.id.tvSheetSubInfo)
        recyclerStages = findViewById(R.id.recyclerStages)

        findViewById<MaterialButton>(R.id.btnBackSheet).setOnClickListener { finish() }

        recyclerStages.layoutManager = LinearLayoutManager(this)
        stageAdapter = StageRowAdapter(
            stages = emptyList(),
            onEditStage = { row -> showAddOrEditStageDialog(row) },
            onDeleteStage = { row -> deleteStageRow(row) }
        )
        recyclerStages.adapter = stageAdapter

        findViewById<MaterialButton>(R.id.btnAddStageRow).setOnClickListener {
            showAddOrEditStageDialog(null)
        }

        findViewById<MaterialButton>(R.id.btnEditCropMeta).setOnClickListener {
            showEditCropInfoDialog()
        }

        findViewById<MaterialButton>(R.id.btnCsvSheet).setOnClickListener {
            showCsvImportExportDialog()
        }

        findViewById<MaterialButton>(R.id.btnLinkThisSheet).setOnClickListener {
            startLinkSheetWizard()
        }

        reloadCrop()

        if (autoLink && currentCrop != null) {
            startLinkSheetWizard()
        }
    }

    private fun reloadCrop() {
        currentCrop = AgroRepository.getCropById(this, cropId)
        val c = currentCrop
        if (c == null) {
            finish()
            return
        }
        tvSheetHeaderTitle.text = "${c.cropName} - Master Sheet"
        tvSheetSubInfo.text = "${c.season} • કુલ ${c.stages.size} તબક્કા (નવો તબક્કો ઉમેરતા જ બધા લિંક ખેડૂતોમાં ઓટો ઉમેરાશે)"
        stageAdapter.updateStages(c.stages)
    }

    private fun showAddOrEditStageDialog(existing: CropStageRow?) {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_stage, null)
        val etDay: EditText = v.findViewById(R.id.etStageDay)
        val etTitle: EditText = v.findViewById(R.id.etStageTitleInput)
        val etMsg: EditText = v.findViewById(R.id.etStageMessageGuj)

        if (existing != null) {
            etDay.setText(existing.dayOffset.toString())
            etTitle.setText(existing.stageTitle)
            etMsg.setText(existing.messageGujarati)
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "નવો તબક્કો (Stage) ઉમેરો" else "તબક્કો (Stage) સુધારો")
            .setView(v)
            .setPositiveButton("Save & Sync") { _, _ ->
                val dayVal = (etDay.text.toString().trim().toIntOrNull() ?: 0).coerceAtLeast(0)
                val titleVal = etTitle.text.toString().trim()
                val msgVal = etMsg.text.toString().trim()
                if (titleVal.isEmpty() || msgVal.isEmpty()) {
                    Toast.makeText(this, "અવસ્થા અને ગુજરાતી સંદેશ બંને લખવા જરૂરી છે", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val list = c.stages.toMutableList()
                if (existing != null) {
                    val idx = list.indexOfFirst { it.id == existing.id }
                    if (idx >= 0) {
                        list[idx] = existing.copy(dayOffset = dayVal, stageTitle = titleVal, messageGujarati = msgVal)
                    }
                } else {
                    list.add(CropStageRow(UUID.randomUUID().toString(), dayVal, titleVal, msgVal))
                }
                AgroRepository.upsertCrop(this, c.copy(stages = list.sortedBy { it.dayOffset }))
                val autoSent = AgroRepository.processDueSchedulesAutomatically(this)
                reloadCrop()
                val msgToast = if (autoSent > 0) {
                    "શીટ સેવ થઈ અને $autoSent ખેડૂતોને આજનો મેસેજ ઓટો મોકલાઈ ગયો!"
                } else {
                    "શીટ સેવ થઈ અને બધા લિંક ખેડૂતોના શેડ્યૂલમાં ઉમેરાઈ ગઈ!"
                }
                Toast.makeText(this, msgToast, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteStageRow(row: CropStageRow) {
        val c = currentCrop ?: return
        AlertDialog.Builder(this)
            .setTitle("આ તબક્કો Delete કરવો છે?")
            .setMessage("દિવસ ${row.dayOffset}: ${row.stageTitle}")
            .setPositiveButton("Delete") { _, _ ->
                val updated = c.stages.filterNot { it.id == row.id }
                AgroRepository.upsertCrop(this, c.copy(stages = updated))
                reloadCrop()
                Toast.makeText(this, "Stage delete thayu", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditCropInfoDialog() {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_crop, null)
        val etName: EditText = v.findViewById(R.id.etCropNameInput)
        val etSeason: EditText = v.findViewById(R.id.etCropSeasonInput)
        val etWeather: EditText = v.findViewById(R.id.etCropWeatherInput)

        etName.setText(c.cropName)
        etSeason.setText(c.season)
        etWeather.setText(c.weatherNote)

        AlertDialog.Builder(this)
            .setTitle("પાકની વિગત સુધારો")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val n = etName.text.toString().trim()
                if (n.isNotEmpty()) {
                    AgroRepository.upsertCrop(
                        this,
                        c.copy(
                            cropName = n,
                            season = etSeason.text.toString().trim().ifEmpty { c.season },
                            weatherNote = etWeather.text.toString().trim()
                        )
                    )
                    reloadCrop()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCsvImportExportDialog() {
        val c = currentCrop ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_csv_sheet, null)
        val etCsv: EditText = v.findViewById(R.id.etCsvContent)
        etCsv.setText(AgroRepository.exportCropSheetCsv(c))

        AlertDialog.Builder(this)
            .setTitle("CSV Sheet Import / Export")
            .setView(v)
            .setPositiveButton("Import & Sync") { _, _ ->
                val parsed = AgroRepository.parseCsvToStageRows(etCsv.text.toString())
                if (parsed.isEmpty()) {
                    Toast.makeText(this, "Valid CSV rows mali nathi", Toast.LENGTH_SHORT).show()
                } else {
                    AgroRepository.upsertCrop(this, c.copy(stages = parsed))
                    reloadCrop()
                    Toast.makeText(this, "${parsed.size} stages import & sync thai gaya!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Copy CSV") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CropSheetCSV", etCsv.text.toString()))
                Toast.makeText(this, "CSV copy thai gayo!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun startLinkSheetWizard() {
        val c = currentCrop ?: return
        if (c.stages.isEmpty()) {
            Toast.makeText(this, "પહેલા શીટમાં ઓછામાં ઓછો ૧ તબક્કો ઉમેરો!", Toast.LENGTH_SHORT).show()
            return
        }

        // Step 1: Select Target Groups & Individual Farmers
        RecipientPickerDialog.show(
            this,
            title = "${c.cropName} શીટ - કયા ગ્રુપ કે ખેડૂતને લિંક કરવી?"
        ) { recipients, _ ->
            showIndividualSowingDatesDialog(c, recipients)
        }
    }

    private fun showIndividualSowingDatesDialog(crop: CropMasterSheet, recipients: List<FarmerContact>) {
        val existingEnrolls = AgroRepository.getEnrollments(this)
        val dateMap = mutableMapOf<String, LocalDate>()
        for (f in recipients) {
            val prev = existingEnrolls.firstOrNull { it.farmerId == f.id && it.cropId == crop.id }
            dateMap[f.id] = if (prev != null) {
                try {
                    LocalDate.parse(prev.sowingDateIso)
                } catch (_: Exception) {
                    LocalDate.now()
                }
            } else {
                LocalDate.now()
            }
        }

        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 16)
        }
        scroll.addView(container)

        val infoTv = TextView(this).apply {
            text = "દરેક ખેડૂતની વાવણી તારીખ અલગ-અલગ સેટ કરી શકો છો (જો ૧૦ દિવસ પહેલા વાવેતર થયું હશે તો બાકીના તબક્કા તરત Due/Send થશે):"
            textSize = 13f
            setPadding(0, 0, 0, 16)
        }
        container.addView(infoTv)

        val btnMap = mutableMapOf<String, MaterialButton>()
        val fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH)

        val btnSameForAll = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "📅 બધા ખેડૂતો માટે એક જ વાવણી તારીખ પસંદ કરો"
            setOnClickListener {
                val initD = dateMap.values.firstOrNull() ?: LocalDate.now()
                DatePickerDialog(
                    this@CropSheetDetailActivity,
                    { _, y, m, d ->
                        val chosen = LocalDate.of(y, m + 1, d)
                        for (f in recipients) {
                            dateMap[f.id] = chosen
                            btnMap[f.id]?.text = "વાવણી: ${chosen.format(fmt)}"
                        }
                    },
                    initD.year,
                    initD.monthValue - 1,
                    initD.dayOfMonth
                ).show()
            }
        }
        container.addView(btnSameForAll)

        for (f in recipients) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 10, 0, 10)
            }
            val nameTv = TextView(this).apply {
                text = "${f.name}\n(+91 ${f.phone})"
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val dBtn = MaterialButton(this).apply {
                text = "વાવણી: ${(dateMap[f.id] ?: LocalDate.now()).format(fmt)}"
                textSize = 12f
                setOnClickListener {
                    val curD = dateMap[f.id] ?: LocalDate.now()
                    DatePickerDialog(
                        this@CropSheetDetailActivity,
                        { _, y, m, d ->
                            val picked = LocalDate.of(y, m + 1, d)
                            dateMap[f.id] = picked
                            text = "વાવણી: ${picked.format(fmt)}"
                        },
                        curD.year,
                        curD.monthValue - 1,
                        curD.dayOfMonth
                    ).show()
                }
            }
            btnMap[f.id] = dBtn
            row.addView(nameTv)
            row.addView(dBtn)
            container.addView(row)
        }

        val cbYearly = CheckBox(this).apply {
            text = "દર વર્ષે આ જ તારીખે ઓટોમેટિક રિપીટ કરો (Yearly Auto-Repeat)"
            isChecked = true
            setPadding(0, 16, 0, 8)
        }
        container.addView(cbYearly)

        AlertDialog.Builder(this)
            .setTitle("${crop.cropName} - ખેડૂત મુજબ વાવણી તારીખ")
            .setView(scroll)
            .setPositiveButton("Save & Auto-Schedule") { _, _ ->
                val count = AgroRepository.enrollFarmersWithIndividualDates(
                    context = this,
                    crop = crop,
                    farmerSowingDates = dateMap,
                    repeatYearly = cbYearly.isChecked
                )
                val autoSent = AgroRepository.processDueSchedulesAutomatically(this)
                val msg = if (autoSent > 0) {
                    "$count ખેડૂતોનું શેડ્યૂલ બની ગયું અને $autoSent આજના Due SMS ઓટો મોકલાઈ ગયા!"
                } else {
                    "$count ખેડૂતોની અલગ-અલગ વાવણી તારીખ મુજબ શેડ્યૂલ સેટ થઈ ગયું!"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
