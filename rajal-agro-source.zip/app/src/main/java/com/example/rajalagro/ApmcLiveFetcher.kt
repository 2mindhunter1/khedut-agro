package com.example.rajalagro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import java.util.regex.Pattern

data class ApmcFetchOutcome(
    val isUpdatedToday: Boolean,
    val effectiveDateIso: String,
    val statusMessage: String,
    val fetchedRates: List<ApmcCropRate>
)

object ApmcLiveFetcher {

    const val URL_RAJKOT = "https://www.apmcrajkot.com/daily_rates"
    const val URL_GONDAL = "https://apmcgondal.scmsolution.in/Daily_Rate.aspx"
    const val URL_MORBI = "https://www.khedutbajarbhav.online/markets/Morbi"

    private val GUJ_MONTHS = mapOf(
        "જાન્યુઆરી" to 1,
        "ફેબ્રુઆરી" to 2,
        "માર્ચ" to 3,
        "એપ્રિલ" to 4,
        "મે" to 5,
        "જૂન" to 6,
        "જુલાઈ" to 7,
        "ઓગસ્ટ" to 8,
        "સપ્ટેમ્બર" to 9,
        "ઓક્ટોબર" to 10,
        "નવેમ્બર" to 11,
        "ડિસેમ્બર" to 12
    )

    suspend fun fetchLiveRates(yard: ApmcYard): ApmcFetchOutcome = withContext(Dispatchers.IO) {
        val url = yard.sourceUrl.trim().ifEmpty { guessDefaultUrl(yard.yardName) }
        if (url.isEmpty()) {
            return@withContext ApmcFetchOutcome(
                isUpdatedToday = false,
                effectiveDateIso = yard.updatedDateIso,
                statusMessage = "⏳ ${yard.yardName} માટે વેબસાઈટ લિંક સેટ નથી — '+ ભાવ' થી ભાવ ઉમેરો (Waiting)",
                fetchedRates = emptyList()
            )
        }

        val today = LocalDate.now()
        val todayDash = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
        val todaySlash = today.format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH))

        try {
            val html = downloadHtml(url)
            if (html.isNullOrBlank()) {
                return@withContext ApmcFetchOutcome(
                    isUpdatedToday = false,
                    effectiveDateIso = yard.updatedDateIso,
                    statusMessage = "⏳ ${yard.yardName} વેબસાઈટ હાલ કનેક્ટ થઈ નથી (Waiting...)",
                    fetchedRates = emptyList()
                )
            }

            return@withContext when {
                url.contains("apmcrajkot.com", ignoreCase = true) -> {
                    parseRajkotApmc(html, today, todayDash, todaySlash)
                }
                url.contains("apmcgondal", ignoreCase = true) -> {
                    parseGondalApmc(url, html, today, todayDash, todaySlash)
                }
                url.contains("khedutbajarbhav.online", ignoreCase = true) -> {
                    parseKhedutBajarBhav(yard.yardName, html, today, todayDash)
                }
                else -> {
                    parseGenericApmcPage(yard.yardName, html, today, todayDash, todaySlash)
                }
            }
        } catch (_: Exception) {
            return@withContext ApmcFetchOutcome(
                isUpdatedToday = false,
                effectiveDateIso = yard.updatedDateIso,
                statusMessage = "⏳ ${yard.yardName} ના આજના ($todayDash) ભાવ હજુ Waiting માં છે",
                fetchedRates = emptyList()
            )
        }
    }

    private fun guessDefaultUrl(yardName: String): String {
        val lower = yardName.lowercase(Locale.ENGLISH)
        return when {
            yardName.contains("રાજકોટ") || lower.contains("rajkot") -> URL_RAJKOT
            yardName.contains("ગોંડલ") || lower.contains("gondal") -> URL_GONDAL
            yardName.contains("મોરબી") || lower.contains("morbi") -> URL_MORBI
            else -> ""
        }
    }

    private fun downloadHtml(urlStr: String): String? {
        return try {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "gu,en-US;q=0.9,en;q=0.8")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    // 1. RAJKOT APMC (https://www.apmcrajkot.com/daily_rates)
    private fun parseRajkotApmc(
        html: String,
        today: LocalDate,
        todayDash: String,
        todaySlash: String
    ): ApmcFetchOutcome {
        val tableRates = extractHtmlTableRates(html)
        val hasToday = html.contains(todaySlash) || html.contains(todayDash)
        val dataNotFound = html.contains("Data Not Found", ignoreCase = true)

        if (hasToday && tableRates.isNotEmpty() && !dataNotFound) {
            return ApmcFetchOutcome(
                isUpdatedToday = true,
                effectiveDateIso = today.toString(),
                statusMessage = "✓ રાજકોટ APMC ના આજના ($todayDash) અધિકૃત ભાવ અપડેટ થઈ ગયા છે",
                fetchedRates = tableRates
            )
        }

        // Parse live scrolling ticker on apmcrajkot.com/daily_rates (e.g. "જીરૂ 4700 5054 કપાસ બી.ટી. 1796 1909")
        val tickerRates = extractGujaratiNameMinMaxPairs(html)
        if (tickerRates.isNotEmpty()) {
            return ApmcFetchOutcome(
                isUpdatedToday = false,
                effectiveDateIso = "",
                statusMessage = "⏳ આજની ($todayDash) ટેબલ એન્ટ્રી હજુ Waiting માં છે • નીચે રાજકોટ APMC Live Ticker ના છેલ્લા હરાજી ભાવ છે",
                fetchedRates = tickerRates
            )
        }

        return ApmcFetchOutcome(
            isUpdatedToday = false,
            effectiveDateIso = "",
            statusMessage = "⏳ રાજકોટ APMC ના આજના ($todayDash) ભાવ હજુ અપડેટ થયા નથી (Data Not Found - Waiting...)",
            fetchedRates = emptyList()
        )
    }

    // 2. GONDAL APMC (https://apmcgondal.scmsolution.in/Daily_Rate.aspx)
    private fun parseGondalApmc(
        url: String,
        initialHtml: String,
        today: LocalDate,
        todayDash: String,
        todaySlash: String
    ): ApmcFetchOutcome {
        var htmlToParse = initialHtml
        var rates = extractHtmlTableRates(htmlToParse)

        // If ASP.NET page needs a postback to load today's GridView
        if (rates.isEmpty() && htmlToParse.contains("__VIEWSTATE")) {
            val posted = tryAspNetPostback(url, htmlToParse, todaySlash)
            if (!posted.isNullOrBlank()) {
                htmlToParse = posted
                rates = extractHtmlTableRates(htmlToParse)
            }
        }

        val hasToday = htmlToParse.contains(todaySlash) || htmlToParse.contains(todayDash)
        if (rates.isNotEmpty()) {
            return ApmcFetchOutcome(
                isUpdatedToday = hasToday,
                effectiveDateIso = if (hasToday) today.toString() else "",
                statusMessage = if (hasToday) {
                    "✓ ગોંડલ APMC ના આજના ($todayDash) અધિકૃત ભાવ અપડેટ થઈ ગયા છે"
                } else {
                    "⏳ ગોંડલ APMC ના આજના ($todayDash) ભાવની રાહ જોવાઈ રહી છે • નીચે છેલ્લા ઉપલબ્ધ ભાવ છે"
                },
                fetchedRates = rates
            )
        }

        return ApmcFetchOutcome(
            isUpdatedToday = false,
            effectiveDateIso = "",
            statusMessage = "⏳ ગોંડલ APMC ના આજના ($todayDash) ભાવ હજુ અપડેટ થયા નથી (Waiting — 'Web' પર જોઈ '+ ભાવ' થી નાખો)",
            fetchedRates = emptyList()
        )
    }

    private fun tryAspNetPostback(urlStr: String, html: String, dateSlash: String): String? {
        return try {
            val vsMatcher = Pattern.compile("id=\"__VIEWSTATE\"\\s+value=\"([^\"]*)\"").matcher(html)
            val evMatcher = Pattern.compile("id=\"__EVENTVALIDATION\"\\s+value=\"([^\"]*)\"").matcher(html)
            val vsgMatcher = Pattern.compile("id=\"__VIEWSTATEGENERATOR\"\\s+value=\"([^\"]*)\"").matcher(html)
            if (!vsMatcher.find()) return null

            val params = mutableListOf<String>()
            params.add("__VIEWSTATE=" + URLEncoder.encode(vsMatcher.group(1) ?: "", "UTF-8"))
            if (vsgMatcher.find()) {
                params.add("__VIEWSTATEGENERATOR=" + URLEncoder.encode(vsgMatcher.group(1) ?: "", "UTF-8"))
            }
            if (evMatcher.find()) {
                params.add("__EVENTVALIDATION=" + URLEncoder.encode(evMatcher.group(1) ?: "", "UTF-8"))
            }

            // Find first text input (date box) and submit button
            val txtInput = Pattern.compile("<input[^>]*type=\"text\"[^>]*name=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE).matcher(html)
            if (txtInput.find()) {
                params.add(URLEncoder.encode(txtInput.group(1) ?: "", "UTF-8") + "=" + URLEncoder.encode(dateSlash, "UTF-8"))
            }
            val subBtn = Pattern.compile("<input[^>]*type=\"submit\"[^>]*name=\"([^\"]+)\"[^>]*value=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE).matcher(html)
            if (subBtn.find()) {
                params.add(URLEncoder.encode(subBtn.group(1) ?: "", "UTF-8") + "=" + URLEncoder.encode(subBtn.group(2) ?: "Search", "UTF-8"))
            }

            val payload = params.joinToString("&").toByteArray(Charsets.UTF_8)
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("User-Agent", "Mozilla/5.0")
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            }
            conn.outputStream.use { it.write(payload) }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    // 3. MORBI / KHEDUTBAJARBHAV (https://www.khedutbajarbhav.online/markets/Morbi)
    private fun parseKhedutBajarBhav(
        yardName: String,
        html: String,
        today: LocalDate,
        todayDash: String
    ): ApmcFetchOutcome {
        val plain = stripHtmlToText(html)

        // Extract Gujarati date on page e.g. "21 નવેમ્બર, 2026"
        var pageDateIso = ""
        var pageDateDisp = ""
        val dateMatcher = Pattern.compile("(\\d{1,2})\\s+(જાન્યુઆરી|ફેબ્રુઆરી|માર્ચ|એપ્રિલ|મે|જૂન|જુલાઈ|ઓગસ્ટ|સપ્ટેમ્બર|ઓક્ટોબર|નવેમ્બર|ડિસેમ્બર)[,\\s]+(20\\d{2})").matcher(plain)
        if (dateMatcher.find()) {
            val d = dateMatcher.group(1)?.toIntOrNull() ?: 1
            val m = GUJ_MONTHS[dateMatcher.group(2) ?: ""] ?: 1
            val y = dateMatcher.group(3)?.toIntOrNull() ?: today.year
            try {
                val parsedDate = LocalDate.of(y, m, d)
                pageDateIso = parsedDate.toString()
                pageDateDisp = parsedDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
            } catch (_: Exception) {
            }
        }

        // Extract crop blocks: Gujarati crop name followed by લઘુત્તમ ભાવ ₹1,140 and મહત્તમ ભાવ ₹1,250
        val rates = mutableListOf<ApmcCropRate>()
        val seenCrops = mutableSetOf<String>()
        val blockPattern = Pattern.compile(
            "([\\u0A80-\\u0AFF][\\u0A80-\\u0AFF\\s().-]{1,30}?)\\s+[a-z0-9_]+\\s+\\(૨૦ કિલો\\).*?લઘુત્તમ ભાવ\\s*₹\\s*([0-9,]+).*?મહત્તમ ભાવ\\s*₹\\s*([0-9,]+)",
            Pattern.DOTALL
        )
        val m = blockPattern.matcher(plain)
        while (m.find()) {
            val cName = (m.group(1) ?: "").replace("\\s+".toRegex(), " ").trim()
            val minP = (m.group(2) ?: "").replace(",", "").toIntOrNull() ?: 0
            val maxP = (m.group(3) ?: "").replace(",", "").toIntOrNull() ?: 0
            if (cName.isNotEmpty() && minP > 0 && maxP >= minP && cName !in seenCrops) {
                seenCrops.add(cName)
                rates.add(ApmcCropRate(UUID.randomUUID().toString(), cName, minP, maxP, isSelectedForSend = true))
            }
        }

        if (rates.isEmpty()) {
            rates.addAll(extractHtmlTableRates(html))
        }

        val isToday = (pageDateIso == today.toString())
        if (rates.isNotEmpty()) {
            val statusMsg = if (isToday) {
                "✓ $yardName ના આજના ($todayDash) અધિકૃત ભાવ અપડેટ થઈ ગયા છે"
            } else {
                "⏳ આજના ($todayDash) ભાવ હજુ અપડેટ થયા નથી (Waiting) • વેબસાઈટ પર છેલ્લા ભાવ તા. ${pageDateDisp.ifEmpty { "અગાઉની તારીખ" }} ના છે"
            }
            return ApmcFetchOutcome(
                isUpdatedToday = isToday,
                effectiveDateIso = pageDateIso,
                statusMessage = statusMsg,
                fetchedRates = rates
            )
        }

        return ApmcFetchOutcome(
            isUpdatedToday = false,
            effectiveDateIso = "",
            statusMessage = "⏳ $yardName ના આજના ($todayDash) ભાવ હજુ અપડેટ થયા નથી (Waiting...)",
            fetchedRates = emptyList()
        )
    }

    private fun parseGenericApmcPage(
        yardName: String,
        html: String,
        today: LocalDate,
        todayDash: String,
        todaySlash: String
    ): ApmcFetchOutcome {
        val rates = extractHtmlTableRates(html)
        val hasToday = html.contains(todayDash) || html.contains(todaySlash)
        return if (rates.isNotEmpty()) {
            ApmcFetchOutcome(
                isUpdatedToday = hasToday,
                effectiveDateIso = if (hasToday) today.toString() else "",
                statusMessage = if (hasToday) {
                    "✓ $yardName ના આજના ($todayDash) ભાવ અપડેટ થઈ ગયા છે"
                } else {
                    "⏳ $yardName ના આજના ($todayDash) ભાવ Waiting માં છે • નીચે છેલ્લા ઉપલબ્ધ ભાવ છે"
                },
                fetchedRates = rates
            )
        } else {
            ApmcFetchOutcome(
                isUpdatedToday = false,
                effectiveDateIso = "",
                statusMessage = "⏳ $yardName ના આજના ($todayDash) ભાવ મળ્યા નથી (Waiting — 'Web' પર જુઓ)",
                fetchedRates = emptyList()
            )
        }
    }

    private fun extractHtmlTableRates(html: String): List<ApmcCropRate> {
        val rates = mutableListOf<ApmcCropRate>()
        val seen = mutableSetOf<String>()
        val rowMatcher = Pattern.compile("<tr[^>]*>(.*?)</tr>", Pattern.DOTALL or Pattern.CASE_INSENSITIVE).matcher(html)
        while (rowMatcher.find()) {
            val rowHtml = rowMatcher.group(1) ?: continue
            val cellMatcher = Pattern.compile("<td[^>]*>(.*?)</td>", Pattern.DOTALL or Pattern.CASE_INSENSITIVE).matcher(rowHtml)
            val cells = mutableListOf<String>()
            while (cellMatcher.find()) {
                val clean = stripHtmlToText(cellMatcher.group(1) ?: "")
                if (clean.isNotEmpty()) cells.add(clean)
            }
            if (cells.size >= 3) {
                val cropName = cells[0]
                if (cropName.any { it in '\u0A80'..'\u0AFF' } && cropName.length in 2..32) {
                    val nums = cells.drop(1).mapNotNull {
                        it.replace(",", "").filter { ch -> ch.isDigit() }.toIntOrNull()
                    }.filter { it in 20..50000 }
                    if (nums.size >= 2) {
                        val minP = nums[nums.size - 2]
                        val maxP = nums[nums.size - 1]
                        if (maxP >= minP && cropName !in seen) {
                            seen.add(cropName)
                            rates.add(ApmcCropRate(UUID.randomUUID().toString(), cropName, minP, maxP, true))
                        }
                    }
                }
            }
        }
        return rates
    }

    private fun extractGujaratiNameMinMaxPairs(html: String): List<ApmcCropRate> {
        val text = stripHtmlToText(html)
        val rates = mutableListOf<ApmcCropRate>()
        val seen = mutableSetOf<String>()
        // Matches Gujarati crop name followed by Min and Max numbers (e.g. "જીરૂ 4700 5054")
        val p = Pattern.compile("([\\u0A80-\\u0AFF][\\u0A80-\\u0AFF\\s().-]{1,26}?)\\s+(\\d{2,5})\\s+(\\d{2,5})")
        val m = p.matcher(text)
        while (m.find()) {
            val name = (m.group(1) ?: "").replace("\\s+".toRegex(), " ").trim()
            val minP = m.group(2)?.toIntOrNull() ?: 0
            val maxP = m.group(3)?.toIntOrNull() ?: 0
            if (name.length >= 2 &&
                !name.contains("કિંમતો") &&
                !name.contains("પ્રતિ") &&
                minP in 20..50000 &&
                maxP >= minP &&
                maxP <= 50000 &&
                name !in seen
            ) {
                seen.add(name)
                rates.add(ApmcCropRate(UUID.randomUUID().toString(), name, minP, maxP, true))
            }
        }
        return rates
    }

    // Smart parser when user copies & pastes text from any APMC webpage
    fun parseCopiedWebTextToRates(copiedText: String): List<ApmcCropRate> {
        val rates = mutableListOf<ApmcCropRate>()
        val seen = mutableSetOf<String>()

        // First try KhedutBajarBhav copied text format
        val kbbPattern = Pattern.compile(
            "([\\u0A80-\\u0AFF][\\u0A80-\\u0AFF\\s().-]{1,30}?)\\s+[a-z0-9_]+\\s+\\(૨૦ કિલો\\).*?લઘુત્તમ ભાવ\\s*₹\\s*([0-9,]+).*?મહત્તમ ભાવ\\s*₹\\s*([0-9,]+)",
            Pattern.DOTALL
        )
        val km = kbbPattern.matcher(copiedText)
        while (km.find()) {
            val name = (km.group(1) ?: "").replace("\\s+".toRegex(), " ").trim()
            val minP = (km.group(2) ?: "").replace(",", "").toIntOrNull() ?: 0
            val maxP = (km.group(3) ?: "").replace(",", "").toIntOrNull() ?: 0
            if (name.isNotEmpty() && minP > 0 && maxP >= minP && name !in seen) {
                seen.add(name)
                rates.add(ApmcCropRate(UUID.randomUUID().toString(), name, minP, maxP, true))
            }
        }
        if (rates.isNotEmpty()) return rates

        // Fallback line-by-line / pair extraction
        return extractGujaratiNameMinMaxPairs(copiedText)
    }

    private fun stripHtmlToText(html: String): String {
        return html
            .replace(Regex("<script[^>]*>.*?</script>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), " ")
            .replace(Regex("<style[^>]*>.*?</style>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }
}
