package com.example.rajalagro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import java.util.regex.Pattern

data class ApmcFetchOutcome(
    val isUpdatedToday: Boolean,
    val statusMessage: String,
    val fetchedRates: List<ApmcCropRate>
)

object ApmcLiveFetcher {

    suspend fun fetchLiveRatesIfRajkot(yardName: String): ApmcFetchOutcome = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val todaySlash = today.format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH))
        val todayDash = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))

        if (!yardName.contains("રાજકોટ") && !yardName.lowercase(Locale.ENGLISH).contains("rajkot")) {
            return@withContext ApmcFetchOutcome(
                isUpdatedToday = false,
                statusMessage = "⏳ $yardName માટે ઓનલાઈન API ઉપલબ્ધ નથી — '+ ભાવ ઉમેરો' થી આજના અધિકૃત ભાવ નાખો (Waiting)",
                fetchedRates = emptyList()
            )
        }

        try {
            val urlsToTry = listOf(
                "https://www.apmcrajkot.com/daily_market.php",
                "https://apmcrajkot.com/daily_market.php"
            )
            var html: String? = null
            for (u in urlsToTry) {
                try {
                    val conn = (URL(u).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 9000
                        readTimeout = 9000
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "Mozilla/5.0")
                    }
                    if (conn.responseCode == 200) {
                        html = conn.inputStream.bufferedReader().use { it.readText() }
                        if (!html.isNullOrBlank()) break
                    }
                } catch (_: Exception) {
                }
            }

            if (html.isNullOrBlank()) {
                return@withContext ApmcFetchOutcome(
                    isUpdatedToday = false,
                    statusMessage = "⏳ રાજકોટ APMC વેબસાઈટ હાલ કનેક્ટ થઈ નથી (Waiting for Update)",
                    fetchedRates = emptyList()
                )
            }

            // Check if website explicitly says Data Not Found for today
            val hasTodayDate = html.contains(todaySlash) || html.contains(todayDash)
            val dataNotFound = html.contains("Data Not Found", ignoreCase = true)

            // Parse table rows <tr><td>Crop</td><td>Arrival</td><td>Min</td><td>Max</td></tr>
            val parsedRates = mutableListOf<ApmcCropRate>()
            val rowMatcher = Pattern.compile("<tr[^>]*>(.*?)</tr>", Pattern.DOTALL or Pattern.CASE_INSENSITIVE).matcher(html)
            while (rowMatcher.find()) {
                val rowHtml = rowMatcher.group(1) ?: continue
                val cellMatcher = Pattern.compile("<td[^>]*>(.*?)</td>", Pattern.DOTALL or Pattern.CASE_INSENSITIVE).matcher(rowHtml)
                val cells = mutableListOf<String>()
                while (cellMatcher.find()) {
                    val clean = (cellMatcher.group(1) ?: "")
                        .replace(Regex("<[^>]+>"), " ")
                        .replace("&nbsp;", " ")
                        .replace("\\s+".toRegex(), " ")
                        .trim()
                    cells.add(clean)
                }
                if (cells.size >= 4) {
                    val cropName = cells[0]
                    val minVal = cells[2].filter { it.isDigit() }.toIntOrNull()
                    val maxVal = cells[3].filter { it.isDigit() }.toIntOrNull()
                    if (cropName.isNotEmpty() && minVal != null && maxVal != null && minVal > 0 && maxVal >= minVal) {
                        parsedRates.add(
                            ApmcCropRate(
                                id = UUID.randomUUID().toString(),
                                cropName = cropName,
                                minPrice = minVal,
                                maxPrice = maxVal,
                                isSelectedForSend = true
                            )
                        )
                    }
                }
            }

            if (hasTodayDate && parsedRates.isNotEmpty() && !dataNotFound) {
                return@withContext ApmcFetchOutcome(
                    isUpdatedToday = true,
                    statusMessage = "✓ રાજકોટ APMC ના આજના ($todayDash) અધિકૃત ભાવ અપડેટ થઈ ગયા છે",
                    fetchedRates = parsedRates
                )
            } else {
                return@withContext ApmcFetchOutcome(
                    isUpdatedToday = false,
                    statusMessage = "⏳ આજની તારીખ ($todayDash) ના રાજકોટ APMC ના ભાવ હજુ અપડેટ થયા નથી (Data Not Found - Waiting...)",
                    fetchedRates = emptyList()
                )
            }
        } catch (_: Exception) {
            return@withContext ApmcFetchOutcome(
                isUpdatedToday = false,
                statusMessage = "⏳ રાજકોટ APMC ના આજના ભાવ હજુ Waiting માં છે (ઈન્ટરનેટ તપાસો)",
                fetchedRates = emptyList()
            )
        }
    }
}
