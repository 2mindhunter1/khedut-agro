package com.example.rajalagro

data class FarmerGroup(
    val id: String,
    val name: String,
    val description: String = ""
)

data class FarmerContact(
    val id: String,
    val name: String,
    val phone: String, // 10-digit normalized mobile number
    val village: String = "",
    val groupIds: List<String> = emptyList()
)

data class FarmerCropEnrollment(
    val id: String,
    val farmerId: String,
    val cropId: String,
    val sowingDateIso: String, // Individual sowing date per farmer (yyyy-MM-dd)
    val repeatYearly: Boolean = true
)

data class CropStageRow(
    val id: String,
    val dayOffset: Int, // Days after farmer's individual sowing date (e.g. 0, 10, 15, 25)
    val stageTitle: String,
    val messageGujarati: String
)

data class CropMasterSheet(
    val id: String,
    val cropName: String,
    val season: String,
    val weatherNote: String,
    val stages: List<CropStageRow>
)

data class ScheduledAdvisory(
    val id: String,
    val enrollmentId: String,
    val stageId: String,
    val farmerId: String,
    val farmerName: String,
    val farmerPhone: String,
    val cropId: String,
    val cropName: String,
    val sowingDateIso: String,
    val targetDateIso: String,
    val dayOffset: Int,
    val stageTitle: String,
    val messageGujarati: String,
    val repeatYearly: Boolean = true,
    val isSent: Boolean = false,
    val sentChannel: String = "",
    val sentDateIso: String = ""
)

data class ApmcCropRate(
    val id: String,
    val cropName: String,
    val minPrice: Int,
    val maxPrice: Int,
    val isSelectedForSend: Boolean = true
)

data class ApmcYard(
    val id: String,
    val yardName: String,
    val sourceUrl: String = "",
    val updatedDateIso: String = "", // Empty or past date if waiting for today's update
    val isWaitingToday: Boolean = true,
    val statusNote: String = "⏳ આજના ભાવ અપડેટ થવાના બાકી છે (Waiting...)",
    val rates: List<ApmcCropRate> = emptyList()
)
