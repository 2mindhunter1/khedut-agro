package com.example.rajalagro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

data class LiveWeatherInfo(
    val locationName: String,
    val tempC: Double,
    val maxTempC: Double,
    val minTempC: Double,
    val humidity: Int,
    val windKmh: Double,
    val rainProbPercent: Int,
    val gujaratiAdvisoryMessage: String
)

object WeatherService {

    data class YardLocation(val name: String, val lat: Double, val lon: Double)

    val LOCATIONS = listOf(
        YardLocation("મોરબી (Morbi)", 22.8173, 70.8377),
        YardLocation("રાજકોટ (Rajkot)", 22.3039, 70.8022),
        YardLocation("ટંકારા (Tankara)", 22.6586, 70.7420),
        YardLocation("ગોંડલ (Gondal)", 21.9619, 70.7923)
    )

    suspend fun fetchLiveWeather(loc: YardLocation): LiveWeatherInfo = withContext(Dispatchers.IO) {
        val todayStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
        try {
            val apiUrl =
                "https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}" +
                    "&current=temperature_2m,relative_humidity_2m,wind_speed_10m" +
                    "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=Asia%2FKolkata&forecast_days=1"
            val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(body)
                val cur = root.getJSONObject("current")
                val daily = root.getJSONObject("daily")

                val temp = cur.optDouble("temperature_2m", 26.0)
                val hum = cur.optInt("relative_humidity_2m", 45)
                val wind = cur.optDouble("wind_speed_10m", 10.0)

                val maxArr = daily.optJSONArray("temperature_2m_max")
                val minArr = daily.optJSONArray("temperature_2m_min")
                val rainArr = daily.optJSONArray("precipitation_probability_max")

                val maxT = maxArr?.optDouble(0, temp + 4) ?: (temp + 4)
                val minT = minArr?.optDouble(0, temp - 6) ?: (temp - 6)
                val rainP = rainArr?.optInt(0, 0) ?: 0

                val tip = when {
                    rainP >= 40 -> "⚠️ માવઠા / વરસાદની શક્યતા છે. કાપણી કરેલ પાક ઢાંકીને સુરક્ષિત રાખવો અને દવાનો છંટકાવ હાલ પૂરતો મોકૂફ રાખવો."
                    minT <= 13.0 -> "❄️ ઠંડી અને ઝાકળનું પ્રમાણ વધારે રહેશે. જીરું અને શાકભાજીના પાકમાં હળવું પિયત આપવું અને ફૂગનાશક દવાની કાળજી લેવી."
                    wind >= 22.0 -> "💨 પવનની ગતિ વધારે હોવાથી દવાનો છંટકાવ સવારે શાંત પવનમાં જ કરવો."
                    else -> "☀️ હવામાન સ્વચ્છ અને ખેતી કાર્યો માટે અનુકૂળ છે. પાકની અવસ્થા મુજબ દવા-ખાતર અને પિયતનું આયોજન કરી શકાય."
                }

                val msg = buildString {
                    append("🌦️ *રાજલ એગ્રો - ${loc.name} હવામાન સલાહ*\n")
                    append("📅 તારીખ: $todayStr\n\n")
                    append("• હાલનું તાપમાન: $temp °C (મહત્તમ $maxT °C / લઘુત્તમ $minT °C)\n")
                    append("• ભેજનું પ્રમાણ: $hum% | પવન: $wind કિમી/કલાક\n")
                    append("• વરસાદની શક્યતા: $rainP%\n\n")
                    append("🌱 *ખેડૂત સલાહ:* $tip")
                }

                return@withContext LiveWeatherInfo(
                    locationName = loc.name,
                    tempC = temp,
                    maxTempC = maxT,
                    minTempC = minT,
                    humidity = hum,
                    windKmh = wind,
                    rainProbPercent = rainP,
                    gujaratiAdvisoryMessage = msg
                )
            }
        } catch (_: Exception) {
        }

        val fallbackMsg = buildString {
            append("🌦️ *રાજલ એગ્રો - ${loc.name} હવામાન સલાહ*\n")
            append("📅 તારીખ: $todayStr\n\n")
            append("• હાલ ઓફલાઈન મોડ ચાલુ છે. સવારના સમયે ઝાકળ અને ભેજને ધ્યાનમાં રાખી જીરું તથા અન્ય પાકમાં જરૂરિયાત મુજબ ફૂગનાશક દવાનો છંટકાવ કરવો.")
        }
        return@withContext LiveWeatherInfo(
            locationName = loc.name,
            tempC = 25.0,
            maxTempC = 30.0,
            minTempC = 15.0,
            humidity = 45,
            windKmh = 10.0,
            rainProbPercent = 0,
            gujaratiAdvisoryMessage = fallbackMsg
        )
    }
}
