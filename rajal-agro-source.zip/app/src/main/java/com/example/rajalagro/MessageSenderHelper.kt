package com.example.rajalagro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.net.URLEncoder

object MessageSenderHelper {

    fun confirmAndSendSms(
        context: Context,
        recipients: List<FarmerContact>,
        messageText: String,
        onComplete: () -> Unit = {}
    ) {
        if (recipients.isEmpty()) {
            Toast.makeText(context, "કોઈ ખેડૂત કે ગ્રુપ પસંદ કર્યું નથી!", Toast.LENGTH_SHORT).show()
            return
        }
        if (messageText.isBlank()) {
            Toast.makeText(context, "સંદેશ ખાલી છે!", Toast.LENGTH_SHORT).show()
            return
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "પહેલા SMS permission allow કરો", Toast.LENGTH_LONG).show()
            return
        }

        val previewNames = recipients.take(5).joinToString(", ") { it.name } +
            if (recipients.size > 5) " (+${recipients.size - 5} બીજા)" else ""

        AlertDialog.Builder(context)
            .setTitle("Text SMS મોકલવો છે? (${recipients.size} ખેડૂત)")
            .setMessage("આ સંદેશ ફક્ત પસંદ કરેલા ખેડૂતોને જ જશે:\n$previewNames\n\nસંદેશ:\n$messageText")
            .setPositiveButton("SMS મોકલો (${recipients.size})") { _, _ ->
                var sentCount = 0
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                for (farmer in recipients) {
                    val cleanPhone = AgroRepository.normalizePhone(farmer.phone)
                    if (cleanPhone.length == 10) {
                        try {
                            val parts = smsManager.divideMessage(messageText)
                            smsManager.sendMultipartTextMessage("+91$cleanPhone", null, parts, null, null)
                            sentCount++
                        } catch (_: Exception) {
                        }
                    }
                }
                Toast.makeText(context, "$sentCount ખેડૂતોને ગુજરાતી Text SMS મોકલાઈ ગયો!", Toast.LENGTH_LONG).show()
                onComplete()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun startWhatsAppGuidedQueue(
        context: Context,
        recipients: List<FarmerContact>,
        messageText: String,
        index: Int = 0,
        onAllFinished: () -> Unit = {}
    ) {
        if (recipients.isEmpty()) {
            Toast.makeText(context, "કોઈ ખેડૂત કે ગ્રુપ પસંદ કર્યું નથી!", Toast.LENGTH_SHORT).show()
            return
        }
        if (messageText.isBlank()) {
            Toast.makeText(context, "સંદેશ ખાલી છે!", Toast.LENGTH_SHORT).show()
            return
        }

        if (recipients.size == 1 && index == 0) {
            openWhatsAppSingle(context, recipients[0], messageText)
            onAllFinished()
            return
        }

        if (index >= recipients.size) {
            Toast.makeText(context, "બધા ${recipients.size} ખેડૂતોને WhatsApp સંદેશ મોકલાઈ ગયા!", Toast.LENGTH_LONG).show()
            onAllFinished()
            return
        }

        val currentFarmer = recipients[index]
        AlertDialog.Builder(context)
            .setTitle("WhatsApp Sender (${index + 1} / ${recipients.size})")
            .setMessage(
                "ખેડૂત: ${currentFarmer.name} (+91 ${currentFarmer.phone})\n\n" +
                    "1. નીચે 'Open WhatsApp' પર tap કરો\n" +
                    "2. WhatsApp માં Send દબાવીને Back આવો\n" +
                    "3. પછી આગલા ખેડૂત માટે દબાવો."
            )
            .setPositiveButton("Open WhatsApp (${index + 1}/${recipients.size})") { _, _ ->
                openWhatsAppSingle(context, currentFarmer, messageText)
                if (index + 1 < recipients.size) {
                    startWhatsAppGuidedQueue(context, recipients, messageText, index + 1, onAllFinished)
                } else {
                    onAllFinished()
                }
            }
            .setNeutralButton("Skip") { _, _ ->
                startWhatsAppGuidedQueue(context, recipients, messageText, index + 1, onAllFinished)
            }
            .setNegativeButton("Stop", null)
            .show()
    }

    fun openWhatsAppSingle(context: Context, farmer: FarmerContact, messageText: String) {
        val cleanPhone = AgroRepository.normalizePhone(farmer.phone)
        if (cleanPhone.length != 10) {
            Toast.makeText(context, "${farmer.name} નો મોબાઈલ નંબર ખોટો છે", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val encoded = URLEncoder.encode(messageText, "UTF-8")
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=91$cleanPhone&text=$encoded")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "WhatsApp ખુલી શક્યું નથી", Toast.LENGTH_SHORT).show()
        }
    }
}
