package com.example.rajalagro

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

object AgroRepository {

    private const val PREFS_NAME = "rajal_agro_prefs_v2"
    private const val KEY_GROUPS = "groups_json"
    private const val KEY_FARMERS = "farmers_json"
    private const val KEY_CROPS = "crops_json"
    private const val KEY_ENROLLMENTS = "enrollments_json"
    private const val KEY_SCHEDULES = "schedules_json"
    private const val KEY_APMC = "apmc_json"
    private const val KEY_SEEDED = "seeded_v2"
    private const val KEY_AUTO_SMS = "auto_sms_enabled"
    private const val KEY_AUTO_HOUR = "auto_send_hour"
    private const val KEY_AUTO_MIN = "auto_send_min"

    fun normalizePhone(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return if (digits.length >= 10) digits.takeLast(10) else digits
    }

    fun formatDateDisplay(isoDate: String): String {
        if (isoDate.isBlank()) return "Waiting"
        return try {
            val d = LocalDate.parse(isoDate)
            d.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH))
        } catch (_: Exception) {
            isoDate
        }
    }

    fun isAutoSmsEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_SMS, true)
    }

    fun setAutoSmsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO_SMS, enabled).apply()
    }

    fun getAutoSendTime(context: Context): Pair<Int, Int> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_AUTO_HOUR, 9) to prefs.getInt(KEY_AUTO_MIN, 0)
    }

    fun setAutoSendTime(context: Context, hour: Int, minute: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_AUTO_HOUR, hour)
            .putInt(KEY_AUTO_MIN, minute)
            .apply()
    }

    fun ensureSeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SEEDED, false)) return

        val grpJeeru = FarmerGroup(UUID.randomUUID().toString(), "જીરું ગ્રુપ - મોરબી", "શિયાળુ જીરું વાવેતર કરતા ખેડૂતો")
        val grpKapas = FarmerGroup(UUID.randomUUID().toString(), "કપાસ ગ્રુપ - રાજકોટ", "ચોમાસુ કપાસ વાવેતર કરતા ખેડૂતો")
        val grpMagfali = FarmerGroup(UUID.randomUUID().toString(), "મગફળી ગ્રુપ", "મગફળી પાક ગ્રુપ")
        saveGroups(context, listOf(grpJeeru, grpKapas, grpMagfali))

        val sampleFarmers = listOf(
            FarmerContact(UUID.randomUUID().toString(), "રમેશભાઈ પટેલ", "9876543210", "કલ્યાણપર", listOf(grpJeeru.id)),
            FarmerContact(UUID.randomUUID().toString(), "મહેશભાઈ ગજેરા", "9876543211", "ટંકારા", listOf(grpJeeru.id, grpKapas.id))
        )
        saveFarmers(context, sampleFarmers)

        val defaultCrops = listOf(
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "જીરું",
                season = "શિયાળુ (ઠંડી ઋતુ)",
                weatherNote = "સૂકું અને ઠંડું હવામાન ઉત્તમ; વાદળછાયા વાતાવરણમાં ચારાનો રોગ આવે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને પ્રથમ પિયત",
                        "નમસ્તે ખેડૂત મિત્ર, જીરુંના વાવેતર બાદ તરત જ હળવું પિયત આપવું જેથી બીજનો ઉગાવો એકસરખો અને ઝડપી થાય."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        15,
                        "નીંદામણ અને બીજું પિયત",
                        "જીરુંના વાવેતરને ૧૫ દિવસ થયા છે. ખેતરમાંથી નીંદામણ દૂર કરી જરૂરિયાત મુજબ બીજું હળવું પિયત આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        25,
                        "મોલો-મશી અને ચારા નિયંત્રણ",
                        "જીરુંનો પાક ૨૫ દિવસનો થયો છે. વાદળછાયા વાતાવરણ કે ઝાકળમાં ચારો અને મોલો-મશી ન આવે તે માટે ભલામણ મુજબ ફૂગનાશક અને ચૂસિયા પ્રકારની દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "ફૂલ અને દાણા બંધાવવાની અવસ્થા",
                        "જીરુંમાં ફૂલ આવવાની અવસ્થા શરૂ થઈ છે. ઠંડી અને ઝાકળથી પાકને બચાવવા હળવું પિયત આપવું અને પોષક તત્વોનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        70,
                        "દાણા પાકવાની અવસ્થા",
                        "જીરુંના દાણા ભરાવાની અવસ્થા છે. વધારે પડતું પિયત ટાળવું અને પાક પીળો પડવા લાગે ત્યારે કાપણીની તૈયારી કરવી."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "કપાસ",
                season = "ચોમાસુ (ખરીફ ઋતુ)",
                weatherNote = "વધુ વરસાદમાં પાણી ભરાવા ન દેવું; ભેજવાળા વાતાવરણમાં ચૂસિયા જીવાત વધે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને પાયાનું ખાતર",
                        "કપાસના વાવેતર સમયે ભલામણ મુજબ પાયાનું ખાતર આપવું અને ખેતરમાં વરસાદી પાણી ભરાઈ ન રહે તે માટે નિકાલની વ્યવસ્થા રાખવી."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        20,
                        "આંતરખેડ અને ચૂસિયા જીવાત",
                        "કપાસના પાકને ૨૦ દિવસ થયા છે. આંતરખેડ કરી નીંદામણ સાફ કરવું અને તડતડિયા તથા સફેદ માખીના નિયંત્રણ માટે દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "પૂર્તિ ખાતર અને ફૂલ-ભમરી અવસ્થા",
                        "કપાસમાં ફૂલ-ભમરી બેસવાની અવસ્થા છે. નાઈટ્રોજનયુક્ત પૂર્તિ ખાતર આપવું અને ગુલાબી ઈયળ માટે ફેરોમેન ટ્રેપ લગાવવા."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        75,
                        "જીંડવા વિકાસ અને પોષણ",
                        "કપાસમાં જીંડવા વિકાસની અવસ્થા ચાલી રહી છે. પાન લાલ થતા અટકાવવા મેગ્નેશિયમ અને સૂક્ષ્મ તત્વોનો છંટકાવ કરવો."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "મગફળી",
                season = "ચોમાસુ / ઉનાળુ",
                weatherNote = "સૂયા બેસતી વખતે જમીનમાં પૂરતો ભેજ જરૂરી છે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "બીજ માવજત અને વાવેતર",
                        "મગફળીના વાવેતર પહેલા બીજને ફૂગનાશક દવાનો પટ આપવો જેથી ઉગાવો સારો થાય અને મૂળનો સડો અટકે."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        25,
                        "નીંદામણ અને પાનના ટપકા રોગ",
                        "મગફળી ૨૫ દિવસની થઈ છે. નીંદામણ દૂર કરવું અને પાનના ટપકા (ટીક્કા રોગ) ના નિયંત્રણ માટે યોગ્ય દવાનો છંટકાવ કરવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        45,
                        "સૂયા બેસવાની અવસ્થા અને જીપ્સમ",
                        "મગફળીમાં સૂયા બેસવાની અવસ્થા શરૂ થઈ છે. ડોડવા સારા ભરાય તે માટે જીપ્સમ (ચિરોડી) આપવું અને ભેજ જાળવી રાખવો."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "ઘઉં",
                season = "શિયાળુ (ઠંડી ઋતુ)",
                weatherNote = "શિયાળાની ઠંડી ઘઉંના ફૂટ અને દાણા ભરાવા માટે અનુકૂળ છે.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને કોરવાણ પિયત",
                        "ઘઉંના વાવેતર બાદ યોગ્ય સમયે પિયત આપવું અને પાયાના ખાતરનો પૂરો ડોઝ આપવો."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        21,
                        "તાજમૂળ અવસ્થા (મહત્વનું પિયત)",
                        "ઘઉંના વાવેતરને ૨૧ દિવસ થયા છે. આ તાજમૂળ ફૂટવાની અવસ્થા હોવાથી સમયસર પિયત અને પૂર્તિ ખાતર અવશ્ય આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        55,
                        "કંટી નીકળવાની અવસ્થા",
                        "ઘઉંમાં કંટી નીકળવાની અવસ્થા શરૂ થઈ છે. આ સમયે જમીનમાં ભેજની ખેંચ ન પડે તેનું ખાસ ધ્યાન રાખવું."
                    )
                )
            ),
            CropMasterSheet(
                id = UUID.randomUUID().toString(),
                cropName = "તલ",
                season = "ઉનાળુ (ગરમ ઋતુ)",
                weatherNote = "ઉનાળાની ગરમીમાં નિયમિત અંતરે હળવું પિયત આપવું.",
                stages = listOf(
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        0,
                        "વાવેતર અને ઉગાવો",
                        "ઉનાળુ તલના વાવેતર બાદ બીજ ઊગી નીકળે ત્યાં સુધી હળવું પિયત આપવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        20,
                        "પારવણી અને નીંદામણ",
                        "તલના પાકને ૨૦ દિવસ થયા છે. વધારાના છોડ દૂર કરી પારવણી કરવી અને નીંદામણ સાફ કરવું."
                    ),
                    CropStageRow(
                        UUID.randomUUID().toString(),
                        40,
                        "ફૂલ અને બૈઢા બેસવાની અવસ્થા",
                        "તલમાં ફૂલ અને બૈઢા બેસવાની અવસ્થા છે. પાન વાળનારી ઈયળ અને ચૂસિયા જીવાત માટે દવાનો છંટકાવ કરવો."
                    )
                )
            )
        )
        saveCrops(context, defaultCrops)

        // Authentic APMC yards with official URLs (starts in Waiting state until fetched)
        val defaultApmc = listOf(
            ApmcYard(
                id = UUID.randomUUID().toString(),
                yardName = "રાજકોટ APMC",
                sourceUrl = ApmcLiveFetcher.URL_RAJKOT,
                updatedDateIso = "",
                isWaitingToday = true,
                statusNote = "⏳ આજના ભાવ ચેક થઈ રહ્યા છે (Waiting...)",
                rates = emptyList()
            ),
            ApmcYard(
                id = UUID.randomUUID().toString(),
                yardName = "ગોંડલ APMC",
                sourceUrl = ApmcLiveFetcher.URL_GONDAL,
                updatedDateIso = "",
                isWaitingToday = true,
                statusNote = "⏳ આજના ભાવ ચેક થઈ રહ્યા છે (Waiting...)",
                rates = emptyList()
            ),
            ApmcYard(
                id = UUID.randomUUID().toString(),
                yardName = "મોરબી APMC",
                sourceUrl = ApmcLiveFetcher.URL_MORBI,
                updatedDateIso = "",
                isWaitingToday = true,
                statusNote = "⏳ આજના ભાવ ચેક થઈ રહ્યા છે (Waiting...)",
                rates = emptyList()
            )
        )
        saveApmcYards(context, defaultApmc)

        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    // --- GROUPS ---
    fun getGroups(context: Context): List<FarmerGroup> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GROUPS, "[]") ?: "[]"
        val list = mutableListOf<FarmerGroup>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(FarmerGroup(o.getString("id"), o.getString("name"), o.optString("description", "")))
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveGroups(context: Context, groups: List<FarmerGroup>) {
        val arr = JSONArray()
        for (g in groups) {
            arr.put(JSONObject().apply {
                put("id", g.id)
                put("name", g.name)
                put("description", g.description)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GROUPS, arr.toString()).apply()
    }

    fun addGroup(context: Context, name: String, desc: String) {
        val all = getGroups(context).toMutableList()
        all.add(FarmerGroup(UUID.randomUUID().toString(), name, desc))
        saveGroups(context, all)
    }

    fun deleteGroup(context: Context, groupId: String) {
        val all = getGroups(context).filterNot { it.id == groupId }
        saveGroups(context, all)
        val updatedFarmers = getFarmers(context).map { f ->
            f.copy(groupIds = f.groupIds.filterNot { it == groupId })
        }
        saveFarmers(context, updatedFarmers)
    }

    // --- FARMERS ---
    fun getFarmers(context: Context): List<FarmerContact> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_FARMERS, "[]") ?: "[]"
        val list = mutableListOf<FarmerContact>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val gIds = mutableListOf<String>()
                val gArr = o.optJSONArray("groupIds")
                if (gArr != null) {
                    for (j in 0 until gArr.length()) gIds.add(gArr.getString(j))
                }
                list.add(
                    FarmerContact(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        phone = o.getString("phone"),
                        village = o.optString("village", ""),
                        groupIds = gIds
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedBy { it.name }
    }

    fun saveFarmers(context: Context, farmers: List<FarmerContact>) {
        val arr = JSONArray()
        for (f in farmers) {
            val gArr = JSONArray()
            f.groupIds.forEach { gArr.put(it) }
            arr.put(JSONObject().apply {
                put("id", f.id)
                put("name", f.name)
                put("phone", f.phone)
                put("village", f.village)
                put("groupIds", gArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_FARMERS, arr.toString()).apply()
    }

    fun upsertFarmer(context: Context, farmer: FarmerContact): FarmerContact {
        val all = getFarmers(context).toMutableList()
        val norm = normalizePhone(farmer.phone)
        val cleanFarmer = farmer.copy(phone = norm)
        val idxById = all.indexOfFirst { it.id == cleanFarmer.id }
        val idxByPhone = all.indexOfFirst { it.phone == norm }
        val saved: FarmerContact
        when {
            idxById >= 0 -> {
                all[idxById] = cleanFarmer
                saved = cleanFarmer
            }
            idxByPhone >= 0 -> {
                val mergedGroups = (all[idxByPhone].groupIds + cleanFarmer.groupIds).distinct()
                saved = all[idxByPhone].copy(
                    name = cleanFarmer.name,
                    village = cleanFarmer.village.ifEmpty { all[idxByPhone].village },
                    groupIds = mergedGroups
                )
                all[idxByPhone] = saved
            }
            else -> {
                all.add(cleanFarmer)
                saved = cleanFarmer
            }
        }
        saveFarmers(context, all)
        syncAllEnrollmentsToSchedules(context)
        return saved
    }

    fun deleteFarmer(context: Context, farmerId: String) {
        val all = getFarmers(context).filterNot { it.id == farmerId }
        saveFarmers(context, all)
        val remEnroll = getEnrollments(context).filterNot { it.farmerId == farmerId }
        saveEnrollments(context, remEnroll)
        syncAllEnrollmentsToSchedules(context)
    }

    fun resolveUniqueRecipients(
        context: Context,
        selectedGroupIds: Set<String>,
        selectedFarmerIds: Set<String>
    ): List<FarmerContact> {
        val allFarmers = getFarmers(context)
        return allFarmers.filter { farmer ->
            farmer.id in selectedFarmerIds || farmer.groupIds.any { it in selectedGroupIds }
        }.distinctBy { it.phone }
    }

    // --- MASTER CROP SHEETS ---
    fun getCrops(context: Context): List<CropMasterSheet> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_CROPS, "[]") ?: "[]"
        val list = mutableListOf<CropMasterSheet>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val stages = mutableListOf<CropStageRow>()
                val sArr = o.optJSONArray("stages")
                if (sArr != null) {
                    for (j in 0 until sArr.length()) {
                        val so = sArr.getJSONObject(j)
                        stages.add(
                            CropStageRow(
                                id = so.getString("id"),
                                dayOffset = so.getInt("dayOffset"),
                                stageTitle = so.getString("stageTitle"),
                                messageGujarati = so.getString("messageGujarati")
                            )
                        )
                    }
                }
                list.add(
                    CropMasterSheet(
                        id = o.getString("id"),
                        cropName = o.getString("cropName"),
                        season = o.optString("season", "બારેમાસ"),
                        weatherNote = o.optString("weatherNote", ""),
                        stages = stages.sortedBy { it.dayOffset }
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun getCropById(context: Context, cropId: String): CropMasterSheet? {
        return getCrops(context).firstOrNull { it.id == cropId }
    }

    fun saveCrops(context: Context, crops: List<CropMasterSheet>) {
        val arr = JSONArray()
        for (c in crops) {
            val sArr = JSONArray()
            for (s in c.stages.sortedBy { it.dayOffset }) {
                sArr.put(JSONObject().apply {
                    put("id", s.id)
                    put("dayOffset", s.dayOffset)
                    put("stageTitle", s.stageTitle)
                    put("messageGujarati", s.messageGujarati)
                })
            }
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("cropName", c.cropName)
                put("season", c.season)
                put("weatherNote", c.weatherNote)
                put("stages", sArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_CROPS, arr.toString()).apply()
    }

    fun upsertCrop(context: Context, crop: CropMasterSheet) {
        val all = getCrops(context).toMutableList()
        val idx = all.indexOfFirst { it.id == crop.id }
        if (idx >= 0) all[idx] = crop else all.add(crop)
        saveCrops(context, all)
        // Automatically sync any newly added/edited/deleted stage rows to all linked farmers & groups!
        syncAllEnrollmentsToSchedules(context)
    }

    fun deleteCrop(context: Context, cropId: String) {
        val all = getCrops(context).filterNot { it.id == cropId }
        saveCrops(context, all)
        val remEnroll = getEnrollments(context).filterNot { it.cropId == cropId }
        saveEnrollments(context, remEnroll)
        syncAllEnrollmentsToSchedules(context)
    }

    fun exportCropSheetCsv(crop: CropMasterSheet): String {
        val sb = StringBuilder()
        sb.append("Day,StageTitle,GujaratiMessage\n")
        for (s in crop.stages.sortedBy { it.dayOffset }) {
            val safeTitle = s.stageTitle.replace("\"", "\"\"")
            val safeMsg = s.messageGujarati.replace("\"", "\"\"").replace("\n", " ")
            sb.append("${s.dayOffset},\"$safeTitle\",\"$safeMsg\"\n")
        }
        return sb.toString()
    }

    fun parseCsvToStageRows(csvText: String): List<CropStageRow> {
        val rows = mutableListOf<CropStageRow>()
        val lines = csvText.lines().filter { it.trim().isNotEmpty() }
        for (line in lines) {
            if (line.trim().startsWith("Day", ignoreCase = true)) continue
            val parts = splitCsvLine(line)
            if (parts.size >= 3) {
                val day = parts[0].trim().toIntOrNull() ?: continue
                val title = parts[1].trim()
                val msg = parts[2].trim()
                if (title.isNotEmpty() && msg.isNotEmpty()) {
                    rows.add(CropStageRow(UUID.randomUUID().toString(), day.coerceAtLeast(0), title, msg))
                }
            }
        }
        return rows.sortedBy { it.dayOffset }
    }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (ch == ',' && !inQuotes) {
                result.add(sb.toString())
                sb.clear()
            } else {
                sb.append(ch)
            }
            i++
        }
        result.add(sb.toString())
        return result
    }

    // --- PER-FARMER CROP ENROLLMENTS (INDIVIDUAL SOWING DATES!) ---
    fun getEnrollments(context: Context): List<FarmerCropEnrollment> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_ENROLLMENTS, "[]") ?: "[]"
        val list = mutableListOf<FarmerCropEnrollment>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FarmerCropEnrollment(
                        id = o.getString("id"),
                        farmerId = o.getString("farmerId"),
                        cropId = o.getString("cropId"),
                        sowingDateIso = o.getString("sowingDateIso"),
                        repeatYearly = o.optBoolean("repeatYearly", true)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveEnrollments(context: Context, items: List<FarmerCropEnrollment>) {
        val arr = JSONArray()
        for (e in items) {
            arr.put(JSONObject().apply {
                put("id", e.id)
                put("farmerId", e.farmerId)
                put("cropId", e.cropId)
                put("sowingDateIso", e.sowingDateIso)
                put("repeatYearly", e.repeatYearly)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_ENROLLMENTS, arr.toString()).apply()
    }

    fun enrollFarmersWithIndividualDates(
        context: Context,
        crop: CropMasterSheet,
        farmerSowingDates: Map<String, LocalDate>,
        repeatYearly: Boolean
    ): Int {
        if (farmerSowingDates.isEmpty()) return 0
        val allEnroll = getEnrollments(context).toMutableList()
        for ((farmerId, sowingDate) in farmerSowingDates) {
            val existingIdx = allEnroll.indexOfFirst { it.farmerId == farmerId && it.cropId == crop.id }
            if (existingIdx >= 0) {
                allEnroll[existingIdx] = allEnroll[existingIdx].copy(
                    sowingDateIso = sowingDate.toString(),
                    repeatYearly = repeatYearly
                )
            } else {
                allEnroll.add(
                    FarmerCropEnrollment(
                        id = UUID.randomUUID().toString(),
                        farmerId = farmerId,
                        cropId = crop.id,
                        sowingDateIso = sowingDate.toString(),
                        repeatYearly = repeatYearly
                    )
                )
            }
        }
        saveEnrollments(context, allEnroll)
        syncAllEnrollmentsToSchedules(context)
        return farmerSowingDates.size
    }

    fun removeEnrollment(context: Context, enrollmentId: String) {
        val updated = getEnrollments(context).filterNot { it.id == enrollmentId }
        saveEnrollments(context, updated)
        syncAllEnrollmentsToSchedules(context)
    }

    // --- DYNAMIC SCHEDULE ENGINE (HANDLES MID-CYCLE ADDITIONS & NEW SHEET STAGES) ---
    fun getSchedules(context: Context): List<ScheduledAdvisory> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_SCHEDULES, "[]") ?: "[]"
        val list = mutableListOf<ScheduledAdvisory>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    ScheduledAdvisory(
                        id = o.getString("id"),
                        enrollmentId = o.optString("enrollmentId", ""),
                        stageId = o.optString("stageId", ""),
                        farmerId = o.optString("farmerId", ""),
                        farmerName = o.optString("farmerName", ""),
                        farmerPhone = o.optString("farmerPhone", ""),
                        cropId = o.optString("cropId", ""),
                        cropName = o.getString("cropName"),
                        sowingDateIso = o.getString("sowingDateIso"),
                        targetDateIso = o.getString("targetDateIso"),
                        dayOffset = o.getInt("dayOffset"),
                        stageTitle = o.getString("stageTitle"),
                        messageGujarati = o.getString("messageGujarati"),
                        repeatYearly = o.optBoolean("repeatYearly", true),
                        isSent = o.optBoolean("isSent", false),
                        sentChannel = o.optString("sentChannel", ""),
                        sentDateIso = o.optString("sentDateIso", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedWith(compareBy<ScheduledAdvisory> { it.isSent }.thenBy { it.targetDateIso }.thenBy { it.farmerName })
    }

    fun saveSchedules(context: Context, items: List<ScheduledAdvisory>) {
        val arr = JSONArray()
        for (s in items) {
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("enrollmentId", s.enrollmentId)
                put("stageId", s.stageId)
                put("farmerId", s.farmerId)
                put("farmerName", s.farmerName)
                put("farmerPhone", s.farmerPhone)
                put("cropId", s.cropId)
                put("cropName", s.cropName)
                put("sowingDateIso", s.sowingDateIso)
                put("targetDateIso", s.targetDateIso)
                put("dayOffset", s.dayOffset)
                put("stageTitle", s.stageTitle)
                put("messageGujarati", s.messageGujarati)
                put("repeatYearly", s.repeatYearly)
                put("isSent", s.isSent)
                put("sentChannel", s.sentChannel)
                put("sentDateIso", s.sentDateIso)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_SCHEDULES, arr.toString()).apply()
    }

    fun syncAllEnrollmentsToSchedules(context: Context) {
        val farmersById = getFarmers(context).associateBy { it.id }
        val cropsById = getCrops(context).associateBy { it.id }
        val enrollments = getEnrollments(context)
        val existingSchedules = getSchedules(context)

        val validPairs = mutableSetOf<String>()
        val resultList = mutableListOf<ScheduledAdvisory>()

        for (enr in enrollments) {
            val farmer = farmersById[enr.farmerId] ?: continue
            val crop = cropsById[enr.cropId] ?: continue
            val sowingDate = try {
                LocalDate.parse(enr.sowingDateIso)
            } catch (_: Exception) {
                continue
            }

            for (stage in crop.stages.sortedBy { it.dayOffset }) {
                val pairKey = "${enr.id}_${stage.id}_${enr.sowingDateIso}"
                validPairs.add(pairKey)

                val targetDate = sowingDate.plusDays(stage.dayOffset.toLong())
                val formattedMsg = buildString {
                    append("🌱 *રાજલ એગ્રો - ${crop.cropName} પાક સલાહ (દિવસ ${stage.dayOffset})*\n")
                    append("👨‍🌾 ખેડૂત: ${farmer.name}\n")
                    append("📌 અવસ્થા: ${stage.stageTitle}\n")
                    append("📅 વાવેતર તારીખ: ${formatDateDisplay(sowingDate.toString())}\n\n")
                    append(stage.messageGujarati)
                }

                val existing = existingSchedules.firstOrNull {
                    it.enrollmentId == enr.id && it.stageId == stage.id && it.sowingDateIso == enr.sowingDateIso
                }

                if (existing != null) {
                    if (existing.isSent) {
                        resultList.add(existing)
                    } else {
                        resultList.add(
                            existing.copy(
                                farmerName = farmer.name,
                                farmerPhone = farmer.phone,
                                cropName = crop.cropName,
                                targetDateIso = targetDate.toString(),
                                dayOffset = stage.dayOffset,
                                stageTitle = stage.stageTitle,
                                messageGujarati = formattedMsg,
                                repeatYearly = enr.repeatYearly
                            )
                        )
                    }
                } else {
                    resultList.add(
                        ScheduledAdvisory(
                            id = UUID.randomUUID().toString(),
                            enrollmentId = enr.id,
                            stageId = stage.id,
                            farmerId = farmer.id,
                            farmerName = farmer.name,
                            farmerPhone = farmer.phone,
                            cropId = crop.id,
                            cropName = crop.cropName,
                            sowingDateIso = enr.sowingDateIso,
                            targetDateIso = targetDate.toString(),
                            dayOffset = stage.dayOffset,
                            stageTitle = stage.stageTitle,
                            messageGujarati = formattedMsg,
                            repeatYearly = enr.repeatYearly,
                            isSent = false
                        )
                    )
                }
            }
        }

        // Keep past sent history even if enrollment changed
        for (old in existingSchedules) {
            val k = "${old.enrollmentId}_${old.stageId}_${old.sowingDateIso}"
            if (old.isSent && k !in validPairs) {
                resultList.add(old)
            }
        }

        saveSchedules(context, resultList)
    }

    fun markScheduleSent(context: Context, scheduleId: String, channel: String) {
        val all = getSchedules(context).toMutableList()
        val idx = all.indexOfFirst { it.id == scheduleId }
        if (idx >= 0) {
            val item = all[idx]
            val todayIso = LocalDate.now().toString()
            all[idx] = item.copy(isSent = true, sentChannel = channel, sentDateIso = todayIso)

            if (item.repeatYearly) {
                try {
                    val nextSowing = LocalDate.parse(item.sowingDateIso).plusYears(1)
                    val nextTarget = LocalDate.parse(item.targetDateIso).plusYears(1)
                    val nextMsg = item.messageGujarati.replace(
                        formatDateDisplay(item.sowingDateIso),
                        formatDateDisplay(nextSowing.toString())
                    )
                    all.add(
                        item.copy(
                            id = UUID.randomUUID().toString(),
                            sowingDateIso = nextSowing.toString(),
                            targetDateIso = nextTarget.toString(),
                            messageGujarati = nextMsg,
                            isSent = false,
                            sentChannel = "",
                            sentDateIso = ""
                        )
                    )
                } catch (_: Exception) {
                }
            }
            saveSchedules(context, all)
        }
    }

    fun deleteSchedule(context: Context, scheduleId: String) {
        val all = getSchedules(context).filterNot { it.id == scheduleId }
        saveSchedules(context, all)
    }

    fun processDueSchedulesAutomatically(context: Context): Int {
        syncAllEnrollmentsToSchedules(context)
        if (!isAutoSmsEnabled(context)) return 0
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return 0
        }

        val todayIso = LocalDate.now().toString()
        val dueItems = getSchedules(context).filter { !it.isSent && it.targetDateIso <= todayIso }
        if (dueItems.isEmpty()) return 0

        val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        var sentCount = 0
        for (item in dueItems) {
            val cleanPhone = normalizePhone(item.farmerPhone)
            if (cleanPhone.length == 10) {
                try {
                    val parts = smsManager.divideMessage(item.messageGujarati)
                    smsManager.sendMultipartTextMessage("+91$cleanPhone", null, parts, null, null)
                    markScheduleSent(context, item.id, "Auto-SMS")
                    sentCount++
                } catch (_: Exception) {
                }
            }
        }
        return sentCount
    }

    // --- APMC YARDS (AUTHENTIC STATUS - NO FAKE PRICES) ---
    fun getApmcYards(context: Context): List<ApmcYard> {
        ensureSeeded(context)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_APMC, "[]") ?: "[]"
        val list = mutableListOf<ApmcYard>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val rates = mutableListOf<ApmcCropRate>()
                val rArr = o.optJSONArray("rates")
                if (rArr != null) {
                    for (j in 0 until rArr.length()) {
                        val ro = rArr.getJSONObject(j)
                        rates.add(
                            ApmcCropRate(
                                id = ro.getString("id"),
                                cropName = ro.getString("cropName"),
                                minPrice = ro.getInt("minPrice"),
                                maxPrice = ro.getInt("maxPrice"),
                                isSelectedForSend = ro.optBoolean("isSelectedForSend", true)
                            )
                        )
                    }
                }
                val uDate = o.optString("updatedDateIso", "")
                val todayIso = LocalDate.now().toString()
                val waiting = if (uDate == todayIso && rates.isNotEmpty()) false else o.optBoolean("isWaitingToday", true)
                list.add(
                    ApmcYard(
                        id = o.getString("id"),
                        yardName = o.getString("yardName"),
                        sourceUrl = o.optString("sourceUrl", ""),
                        updatedDateIso = uDate,
                        isWaitingToday = waiting,
                        statusNote = o.optString("statusNote", "આજના ભાવ અપડેટ થવાના બાકી છે (Waiting...)"),
                        rates = rates
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveApmcYards(context: Context, yards: List<ApmcYard>) {
        val arr = JSONArray()
        for (y in yards) {
            val rArr = JSONArray()
            for (r in y.rates) {
                rArr.put(JSONObject().apply {
                    put("id", r.id)
                    put("cropName", r.cropName)
                    put("minPrice", r.minPrice)
                    put("maxPrice", r.maxPrice)
                    put("isSelectedForSend", r.isSelectedForSend)
                })
            }
            arr.put(JSONObject().apply {
                put("id", y.id)
                put("yardName", y.yardName)
                put("sourceUrl", y.sourceUrl)
                put("updatedDateIso", y.updatedDateIso)
                put("isWaitingToday", y.isWaitingToday)
                put("statusNote", y.statusNote)
                put("rates", rArr)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_APMC, arr.toString()).apply()
    }

    fun upsertApmcYard(context: Context, yard: ApmcYard) {
        val all = getApmcYards(context).toMutableList()
        val idx = all.indexOfFirst { it.id == yard.id }
        if (idx >= 0) all[idx] = yard else all.add(yard)
        saveApmcYards(context, all)
    }

    fun deleteApmcYard(context: Context, yardId: String) {
        val all = getApmcYards(context).filterNot { it.id == yardId }
        saveApmcYards(context, all)
    }

    fun formatSelectedApmcMessageGujarati(yard: ApmcYard): String? {
        val selectedRates = yard.rates.filter { it.isSelectedForSend }
        if (selectedRates.isEmpty()) return null
        val dateLabel = if (yard.updatedDateIso.isNotEmpty()) formatDateDisplay(yard.updatedDateIso) else formatDateDisplay(LocalDate.now().toString())
        val sb = StringBuilder()
        sb.append("📊 *રાજલ એગ્રો - ${yard.yardName} બજાર ભાવ*\n")
        sb.append("📅 તારીખ: $dateLabel (૨૦ કિલો / મણ દીઠ)\n\n")
        for (r in selectedRates) {
            sb.append("• ${r.cropName}: ₹${r.minPrice} થી ₹${r.maxPrice}\n")
        }
        sb.append("\n🙏 ખેડૂત મિત્રો માટે અધિકૃત બજાર ભાવ માહિતી")
        return sb.toString()
    }
}
